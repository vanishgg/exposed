from helper.utils              import *


def main_menu():
 while True:
    os.system("Title [CLOVER] DISCORD.GG/OSINTT | Days Left > 10 | Developed By @novex.")
    clear_screen()
    MainBanner()
    print(f'''                                                               
            {COLOR_L}[{COLOR_L1}01{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Lookup Advanced  {COLOR_L}[{COLOR_L1}06{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Ddoser             {COLOR_L}[{COLOR_L1}11{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Generator     {COLOR_L}[{COLOR_L1}16{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON 
            {COLOR_L}[{COLOR_L1}02{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SnusBase Lookup     {COLOR_L}[{COLOR_L1}07{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Grabber            {COLOR_L}[{COLOR_L1}12{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON             {COLOR_L}[{COLOR_L1}17{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON 
            {COLOR_L}[{COLOR_L1}03{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Dox Creator         {COLOR_L}[{COLOR_L1}08{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Email Tracker         {COLOR_L}[{COLOR_L1}13{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON             {COLOR_L}[{COLOR_L1}18{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON
            {COLOR_L}[{COLOR_L1}04{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Dox Tracker         {COLOR_L}[{COLOR_L1}09{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Grabber            {COLOR_L}[{COLOR_L1}14{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON             {COLOR_L}[{COLOR_L1}19{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON
            {COLOR_L}[{COLOR_L1}05{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Pinger           {COLOR_L}[{COLOR_L1}10{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Ip Grabber {COLOR_L}[{COLOR_L1}LINK{COLOR_L}] {COLOR_L}    [{COLOR_L1}15{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON             {COLOR_L}[{COLOR_L1}N{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY}  |{COLOR_WHITE} New Page
''')
    choice = input(f"            {COLOR_L}[{COLOR_L1}CLOVER{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLOR_L1}INPUT{COLOR_L}] {COLORAMA_GRAY} > {COLOR_WHITE}") 
    if choice == "1":
        os.system("cls")
        MainBanner()
        subprocess.run(["python", "helper/iplookup.py"])
    elif choice == "2":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/SnusLookup.py"])   
    elif choice == "3":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/DoxCreate.py"])
    elif choice == "5":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/Ip-Pinger.py"])    
    elif choice == "4":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/DoxTracker.py"])       
    elif choice == "6":
        os.system("cls")
        stresser2()   
        subprocess.run(["python", "helper/stresser.py"])
    elif choice == "8":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/EmailTracker.py"])
    elif choice == "9":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/IpGrabber.py"])
    elif choice == "10":
        os.system("cls")
        MainBanner()   
        print(f"{TYPE} Dm summoninq. so he can setup your token grabber!") 
    elif choice == "11":
        os.system("cls")
        MainBanner()   
        subprocess.run(["python", "helper/IpGenerator.py"])
    elif choice == "10":
        os.system("cls")

    elif choice == "15":
        pass
    else:
        print(f"            {COLOR_L}[{COLOR_L1}CLOVER{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLORAMA_YELLOW}WRONG CHOICE{COLOR_L}] {COLORAMA_GRAY} > {COLOR_WHITE}")
        time.sleep(0.5)
        main_menu()  # Restart the main menu

# Entry point of the program
if __name__ == "__main__":
    os.system("Title [CLOVER] DISCORD.GG/OSINTT | Days Left > 10 | Developed By @novex.")
    set_console_size()
    display_ascii_banner()
    check_directories()
    main_menu()
