

from utils import *
try:
    import random
    import phonenumbers
    from phonenumbers import geocoder, carrier, timezone
except Exception as e:
   (e)
   


try:
    def NumberInfo(phone_number):
        try:
            parsed_number = phonenumbers.parse(phone_number, None)
            operator_phone = carrier.name_for_number(parsed_number, "fr")
            type_number_phone = "Mobile" if phonenumbers.number_type(parsed_number) == phonenumbers.PhoneNumberType.MOBILE else "Fixe"
            country_phone = phonenumbers.region_code_for_number(parsed_number)
            region_phone = geocoder.description_for_number(parsed_number, "fr")
            timezones = timezone.time_zones_for_number(parsed_number)
            timezone_phone = timezones[0] if timezones else None
        except:
            operator_phone = "None"
            type_number_phone = "None"
            country_phone = "None"
            region_phone = "None"
            timezone_phone = "None"

        return operator_phone, type_number_phone, country_phone, region_phone, timezone_phone

    def IpInfo(ip):
        try:
            response = requests.get(f"https://ipinfo/api/ip/ip={ip}")
            api = response.json()
        except:
            pass

        try:
            isp_ip = api["isp"]
        except:
            isp_ip = "None"
        
        try:
            org_ip = api["org"]
        except:
            org_ip = "None"

        try:
            as_ip = api["as"]
        except:
            as_ip = "None"
        
        return isp_ip, org_ip, as_ip

    def TokenInfo(token):
        try:
            from datetime import datetime, timezone
            user = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token}).json()
            r = requests.get('https://discord.com/api/v8/users/@me', headers={'Authorization': token, 'Content-Type': 'application/json'})
        except:
            pass

        try:
            username_discord = user['username'] + '#' + user['discriminator']
        except:
            username_discord = "None"
        
        try:
            display_name_discord = user['global_name']
        except:
            display_name_discord = "None"

        try:
            user_id_discord = user['id']
        except:
            user_id_discord = "None"

        try:
            avatar_url_discord = f"https://cdn.discordapp.com/avatars/{user_id_discord}/{user['avatar']}.gif" if requests.get(f"https://cdn.discordapp.com/avatars/{user_id_discord}/{user['avatar']}.gif").status_code == 200 else f"https://cdn.discordapp.com/avatars/{user_id_discord}/{user['avatar']}.png"
        except:
            avatar_url_discord = "None"

        try:
            created_at_discord = datetime.fromtimestamp(((int(user['id']) >> 22) + 1420070400000) / 1000, timezone.utc)
        except:
            created_at_discord = "None"

        try:
            email_discord = user['email']
        except:
            email_discord = "None"

        try:
            phone_discord = user['phone']
        except:
            phone_discord = "None"

        try:
            friends = requests.get('https://discord.com/api/v8/users/@me/relationships', headers={'Authorization': token}).json()
            if friends:
                friends_discord = []
                for friend in friends:
                    unprefered_flags = [64, 128, 256, 1048704]
                    data = f"{friend['user']['username']}#{friend['user']['discriminator']} ({friend['user']['id']})"

                    if len('\n'.join(friends_discord)) + len(data) >= 1024:
                        break

                    friends_discord.append(data)

                if len(friends_discord) > 0:
                    friends_discord = '\n' + ' / '.join(friends_discord)
                else:
                    friends_discord = "None"
            else:
                friends_discord = "None"
        except:
            friends_discord = "None"

        try:
            gift_codes = requests.get('https://discord.com/api/v9/users/@me/outbound-promotions/codes', headers={'Authorization': token}).json()
            if gift_codes:
                codes = []
                for gift_codes_discord in gift_codes:
                    name = gift_codes_discord['promotion']['outbound_title']
                    gift_codes_discord = gift_codes_discord['code']
                    data = f"Gift: {name}\nCode: {gift_codes_discord}"
                    if len('\n\n'.join(gift_codes_discord)) + len(data) >= 1024:
                        break
                    gift_codes_discord.append(data)
                if len(gift_codes_discord) > 0:
                    gift_codes_discord = '\n\n'.join(gift_codes_discord)
                else:
                    gift_codes_discord = "None"
            else:
                gift_codes_discord = "None"
        except:
            gift_codes_discord = "None"

        try:
            mfa_discord = user['mfa_enabled']
        except:
            mfa_discord = "None"

        try:
            if user['premium_type'] == 0:
                nitro_discord = 'False'
            elif user['premium_type'] == 1:
                nitro_discord = 'Nitro Classic'
            elif user['premium_type'] == 2:
                nitro_discord = 'Nitro Boosts'
            elif user['premium_type'] == 3:
                nitro_discord = 'Nitro Basic'
            else:
                nitro_discord = 'False'
        except:
            nitro_discord = "None"

        return username_discord, display_name_discord, user_id_discord, avatar_url_discord, created_at_discord, email_discord, phone_discord, nitro_discord, friends_discord, gift_codes_discord, mfa_discord



    by =      input(f"{INPUT} Doxed By      : {Fore.RESET}")
    reason =  input(f"{INPUT} Reason        : {Fore.RESET}")
    pseudo1 = input(f"{INPUT} First Pseudo  : {Fore.RESET}")
    pseudo2 = input(f"{INPUT} Second Pseudo : {Fore.RESET}")

    print(f"\n{TYPE}{COLORAMA_YELLOW} Discord Information:")
    token_input = input(f"{INPUT} Token ? (y/n) -> {Fore.RESET}")
    if token_input in ["y", "Y", "yes", "YES", "Yes"]:
        token = input(f"{INPUT} Token: {Fore.RESET}")
        username_discord, display_name_discord, user_id_discord, avatar_url_discord, created_at_discord, email_discord, phone_discord, nitro_discord, friends_discord, gift_codes_discord, mfa_discord = TokenInfo(token)
    else:
        token = "None"
        username_discord =     input(f"{INPUT} Username      : {Fore.RESET}")
        display_name_discord = input(f"{INPUT} Display Name  : {Fore.RESET}")
        user_id_discord =      input(f"{INPUT} Id            : {Fore.RESET}")
        avatar_url_discord =   input(f"{INPUT} Avatar        : {Fore.RESET}")
        created_at_discord =   input(f"{INPUT} Created At    : {Fore.RESET}")
        email_discord =        input(f"{INPUT} Email         : {Fore.RESET}")
        phone_discord =        input(f"{INPUT} Phone         : {Fore.RESET}")
        nitro_discord =        input(f"{INPUT} Nitro         : {Fore.RESET}")
        friends_discord =      input(f"{INPUT} Friends       : {Fore.RESET}")
        gift_codes_discord =   input(f"{INPUT} Gift Code     : {Fore.RESET}")
        mfa_discord =          input(f"{INPUT} Mfa           : {Fore.RESET}")

    print(f"\n{TYPE}{COLORAMA_YELLOW} Ip Information:")
    ip_public = input(f"{INPUT} Ip Publique   : {Fore.RESET}")
    ip_local =  input(f"{INPUT} Ip Local      : {Fore.RESET}")
    ipv6 =      input(f"{INPUT} Ipv6          : {Fore.RESET}")
    vpn_pc =    input(f"{INPUT} VPN           : {Fore.RESET}")
    isp_ip, org_ip, as_ip = IpInfo(ip_public)

    print(f"\n{TYPE}{COLORAMA_YELLOW} Pc Information:")
    name_pc =         input(f"{INPUT} Name          : {Fore.RESET}")
    username_pcc =    input(f"{INPUT} Username      : {Fore.RESET}")
    displayname_pc =  input(f"{INPUT} Display Name  : {Fore.RESET}")
    platform_pc =     input(f"{INPUT} Platefrom     : {Fore.RESET}")
    exploitation_pc = input(f"{INPUT} Exploitation  : {Fore.RESET}")
    windowskey_pc =   input(f"{INPUT} Windows Key   : {Fore.RESET}")
    mac_pc =          input(f"{INPUT} MAC Adress    : {Fore.RESET}")
    hwid_pc =         input(f"{INPUT} HWID Adress   : {Fore.RESET}")
    cpu_pc =          input(f"{INPUT} CPU           : {Fore.RESET}")
    gpu_pc =          input(f"{INPUT} GPU           : {Fore.RESET}")
    ram_pc =          input(f"{INPUT} RAM           : {Fore.RESET}")
    disk_pc =         input(f"{INPUT} Disk          : {Fore.RESET}")
    mainscreen_pc =   input(f"{INPUT} Screen Main   : {Fore.RESET}")
    secscreen_pc =    input(f"{INPUT} Screen Sec    : {Fore.RESET}")
                    
    print(f"\n{TYPE}{COLORAMA_YELLOW} Number Information:")
    phone_number = input(f"{INPUT} Phone Number  : {Fore.RESET}")
    brand_phone = input(f"{INPUT} Brand         : {Fore.RESET}")
    operator_phone, type_number_phone, country_phone, region_phone, timezone_phone = NumberInfo(phone_number)

    print(f"\n{TYPE}{COLORAMA_YELLOW} Personal Information:")
    gender =     input(f"{INPUT} Gender        : {Fore.RESET}")
    last_name =  input(f"{INPUT} Last Name     : {Fore.RESET}")
    first_name = input(f"{INPUT} First Name    : {Fore.RESET}")
    age =        input(f"{INPUT} Age           : {Fore.RESET}")
    mother =     input(f"{INPUT} Mother        : {Fore.RESET}")
    father =     input(f"{INPUT} Father        : {Fore.RESET}")
    brother =    input(f"{INPUT} Brother       : {Fore.RESET}")
    sister =     input(f"{INPUT} Sister        : {Fore.RESET}")
                
    print(f"\n{TYPE}{COLORAMA_YELLOW} Loc Information:")
    continent =   input(f"{INPUT} Continent     : {Fore.RESET}")
    country =     input(f"{INPUT} Country       : {Fore.RESET}")
    region =      input(f"{INPUT} Region        : {Fore.RESET}")
    postal_code = input(f"{INPUT} Postal Code   : {Fore.RESET}")
    city =        input(f"{INPUT} City          : {Fore.RESET}")
    adress =      input(f"{INPUT} Adress        : {Fore.RESET}")
    timezone =    input(f"{INPUT} Timezone      : {Fore.RESET}")
    longitude =   input(f"{INPUT} Longitude     : {Fore.RESET}")
    latitude =    input(f"{INPUT} Latitude      : {Fore.RESET}")

    print(f"\n{TYPE}{COLORAMA_YELLOW} Social Information:")
    password = input(f"{INPUT} Password      : {Fore.RESET}")
    email =    input(f"{INPUT} Email         : {Fore.RESET}")
            
    print(f"\n{TYPE}{COLORAMA_YELLOW} Other:")
    other =    input(f"{INPUT} Other         : {Fore.RESET}")
    database = input(f"{INPUT} DataBase      : {Fore.RESET}")
    logs =     input(f"{INPUT} Logs          : {Fore.RESET}")


    name_file = input(f"{INPUT} Choose the file name -> {Fore.RESET}")
    if not name_file.strip():
        name_file = f'No Name {random.randint(1, 999)}'

    dox_path_relative = f"\\stats\\DoxCreate\\FUCKED - {name_file}.txt"
    dox_path = os.path.join("stats", "DoxCreate", f"FUCKED - {name_file}.txt")

    with open(dox_path, 'w', encoding='utf-8') as file:
        file.write(f'''
    ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄                                    
                                        
            ██████╗   ██████╗  ██╗  ██╗
            ██╔══██╗ ██╔═══██╗ ╚██╗██╔╝
            ██║  ██║ ██║   ██║  ╚███╔╝ 
            ██║  ██║ ██║   ██║  ██╔██╗ 
            ██████╔╝ ╚██████╔╝ ██╔╝ ██╗ 
            ╚═════╝   ╚═════╝  ╚═╝  ╚═╝   Made By Novex
                                        
                                                                                   
            Doxed By : {by}
            Reason   : {reason}
            Pseudo   : "{pseudo1}", "{pseudo2}"
    
    ▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄▄

           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            DISCORD:
            =====================================================================================
            [+] Username     : {username_discord}
            [+] Display Name : {display_name_discord}
            [+] ID           : {user_id_discord}
            [+] Avatar       : {avatar_url_discord}
            [+] Created At   : {created_at_discord}
            [+] Token        : {token}
            [+] E-Mail       : {email_discord}
            [+] Phone        : {phone_discord}
            [+] Nitro        : {nitro_discord}
            [+] Friends      : {friends_discord}
            [+] Gift Code    : {gift_codes_discord}
            [+] Multi-Factor Authentication : {mfa_discord}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝

           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            INFORMATION:
            =====================================================================================
            +────────────Pc────────────+
            [+] IP Publique  : {ip_public}
            [+] Ip Local     : {ip_local}
            [+] Ipv6         : {ipv6}
            [+] Isp          : {isp_ip}
            [+] Org          : {org_ip}
            [+] As           : {as_ip}

            [+] VPN Y/N      : {vpn_pc}

            [+] Name         : {name_pc}
            [+] Username     : {username_pcc}
            [+] Display Name : {displayname_pc}

            [+] Plateform    : {platform_pc}
            [+] Exploitation : {exploitation_pc}
            [+] Windows Key  : {windowskey_pc}

            [+] MAC          : {mac_pc}
            [+] HWID         : {hwid_pc}
            [+] CPU          : {cpu_pc}
            [+] GPU          : {gpu_pc}
            [+] RAM          : {ram_pc}
            [+] Disk         : {disk_pc}

            [+] Screen Main      : {mainscreen_pc}
            [+] Screen Secondary : {secscreen_pc}

            +───────────Phone──────────+
            [+] Phone Number : {phone_number}
            [+] Brand        : {brand_phone}
            [+] Operator     : {operator_phone}
            [+] Type Number  : {type_number_phone}
            [+] Country      : {country_phone}
            [+] Region       : {region_phone}
            [+] Timezone     : {timezone_phone}

            +───────────Personal───────+
            [+] Gender      : {gender}
            [+] Last Name   : {last_name}
            [+] First Name  : {first_name}
            [+] Age         :  {age}

            [+] Mother      : {mother}
            [+] Father      : {father}
            [+] Brother     : {brother}
            [+] Sister      : {sister}

            +────────────Loc───────────+
            [+] Continent   : {continent}
            [+] Country     : {country}
            [+] Region      : {region}
            [+] Postal Code : {postal_code}
            [+] City        : {city}
            [+] Address     : {adress}
            [+] Timezone    : {timezone}
            [+] Longitude   : {longitude}
            [+] Latitude    : {latitude}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝


           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            SOCIAL:
            =====================================================================================
            +──────Mails & Password─────+
            [+] Email    : {email}
            [+] Password : {password}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝

           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            OTHER:
            =====================================================================================
            {other}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝

           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            DATABASE:
            =====================================================================================
            {database}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝

           ╔═══════════════════════════════════════════════════════════════════════════════════════╗
            LOGS:
            =====================================================================================
            {logs}
           ╚═══════════════════════════════════════════════════════════════════════════════════════╝
    ''')

    print(f" {TYPE} The DOX {COLORAMA_WHITE}\"{name_file}\"{COLOR_L} was sent to: {COLORAMA_WHITE}\"{dox_path_relative}\"")
except Exception as e:
    (e)