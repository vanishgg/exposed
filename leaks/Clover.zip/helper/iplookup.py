import os
import sys
import json
import urllib.request
import webbrowser
from utils      import *
class IPAddressLocator:


    def display_menu(self):

        print(f"                                        {COLOR_L}[{COLOR_L1}01{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Check your IP info")
        print(f"                                        {COLOR_L}[{COLOR_L1}02{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Check other IP info")
        print(f"                                        {COLOR_L}[{COLOR_L1}03{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} EXIT")
        try:
            choice = int(input(f"\n{INPUT} Enter your choice > " + self.W))
            if choice == 1:
                self.lookup_own_ip()
            elif choice == 2:
                self.lookup_ip()
            elif choice == 3:
                print(self.Y + "Exiting..." + self.W)
                sys.exit(0)
            else:
                print(self.R + "\nInvalid choice! Please try again.\n")
                self.display_menu()
        except ValueError:
            print(self.R + "\nInvalid input! Please enter a number.\n")
            self.display_menu()

    def fetch_ip_info(self, url):

        try:
            response = urllib.request.urlopen(url)
            data = json.load(response)
            self.display_ip_info(data)
        except urllib.error.URLError:
            print(self.R + "\nError!" + self.Y + " Please check your internet connection.\n" + self.W)
        except KeyError:
            print(self.R + "\nError! Invalid IP/Website Address.\n" + self.W)
            self.display_menu()

    def display_ip_info(self, data):

        os.system("cls")
        MainBanner()
        print(f"{TYPE} INFORMATION\n")
        print(f"{TYPE} IP Address: " + self.W, data.get('query', 'N/A'))
        print(f"{TYPE} Org: " + self.W, data.get('org', 'N/A'))
        print(f"{TYPE} City: " + self.W, data.get('city', 'N/A'))
        print(f"{TYPE} Region: " + self.W, data.get('regionName', 'N/A'))
        print(f"{TYPE} Country: " + self.W, data.get('country', 'N/A'))
        print(f"{TYPE} Latitude: " + self.W, data.get('lat', 'N/A'))
        print(f"{TYPE} Longitude: " + self.W, data.get('lon', 'N/A'))

        map_link = f"https://www.google.com/maps/place/{data.get('lat', 'N/A')}+{data.get('lon', 'N/A')}"
        print(f"{TYPE} Google Map Link: {Fore.WHITE}{map_link}")

        open_link = input(f"{TYPE} Open link in browser? > y/n > {Fore.WHITE}")
        if open_link.lower() == 'y':
            webbrowser.open(map_link, new=0)

        self.display_menu()

    def lookup_ip(self):

        os.system("cls")
        MainBanner()
        ip_or_url = input(f"{INPUT} Enter IP Address/Website: " + self.W).strip()
        if ip_or_url:
            url = f'http://ip-api.com/json/{ip_or_url}'
            self.fetch_ip_info(url)
        else:
            print(f"{TYPE} \nPlease enter a valid IP Address or website.\n")
            self.lookup_ip()

    def lookup_own_ip(self):

        url = 'http://ip-api.com/json/'
        self.fetch_ip_info(url)

    def run(self):

        try:
            self.display_menu()
        except KeyboardInterrupt:
            print(self.Y + "\nInterrupted! Have a nice day :)" + self.W)


if __name__ == "__main__":
    locator = IPAddressLocator()
    locator.run()
