from utils import *
try:
    import threading
    import time
    import socket
except Exception as e:
   (e)


try:
    def ping_ip(hostname, port, bytes):
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(2)
            start_time = time.time() 
            sock.connect((hostname, port))
            data = b'\x00' * bytes
            sock.sendall(data)
            end_time = time.time() 
            elapsed_time = (end_time - start_time) * 1000 
            print(f'{TYPE} Hostname: {COLORAMA_WHITE}{hostname}{COLORAMA_RED} time: {COLORAMA_WHITE}{elapsed_time:.2f}ms{COLORAMA_RED} port: {COLORAMA_WHITE}{port}{COLORAMA_RED} bytes: {COLORAMA_WHITE}{bytes}{COLORAMA_RED} status: {COLORAMA_WHITE}succeed{COLORAMA_RED}')
        except:
            elapsed_time = 0
            print(f' {TYPE} Hostname: {COLORAMA_WHITE}{hostname}{COLORAMA_RED} time: {COLORAMA_WHITE}{elapsed_time}ms{COLORAMA_RED} port: {COLORAMA_WHITE}{port}{COLORAMA_RED} bytes: {COLORAMA_WHITE}{bytes}{COLORAMA_RED} status: {COLORAMA_WHITE}fail{COLORAMA_RED}')


    hostname = input(f" {INPUT} Ip -> ")

    try:
        port_input = input(f" {INPUT} Port (enter for default) -> ")
        if port_input.strip():
            port = int(port_input)
        else:
            port = 80  
        
        bytes_input = input(f" {INPUT} Bytes (enter for default) -> ")
        if bytes_input.strip():
            bytes = int(bytes_input)
        else:
            bytes = 64
    except:
        print(f"{TYPE} ERROR")

    while True:
        ping_ip(hostname, port, bytes)

except Exception as e:
    (e)