from utils import *
try:
    import requests
    import json
    import random
    import threading
    import sys

except Exception as e:
   (e)
   


try:
    webhook = input(f"{INPUT} Webhook ? (y/n) -> {COLORAMA_RESET}")
    if webhook in ['y', 'Y', 'Yes', 'yes', 'YES']:
        webhook_url = input(f"{INPUT} Webhook URL -> {COLORAMA_RESET}")
        

    try:
        threads_number = int(input(f"{INPUT} Threads Number -> {COLORAMA_RESET}"))
    except:
        print(f"{TYPE} ERROR")

    def send_webhook(embed_content):
        payload = {
        'embeds': [embed_content],
        'username': "Etherium - Novex Ip Generator",
        'avatar_url': ""
        }

        headers = {
        'Content-Type': 'application/json'
        }

        requests.post(webhook_url, data=json.dumps(payload), headers=headers)

    number_valid = 0
    number_invalid = 0
    def ip_check():
        global number_valid, number_invalid
        number_1 = random.randint(1, 255)
        number_2 = random.randint(1, 255)
        number_3 = random.randint(1, 255)
        number_4 = random.randint(1, 255)
        ip = f"{number_1}.{number_2}.{number_3}.{number_4}"

        try:
            if sys.platform.startswith("win"):
                result = subprocess.run(['ping', '-n', '1', ip], capture_output=True, text=True, timeout=0.1)
            elif sys.platform.startswith("linux"):
                result = subprocess.run(['ping', '-c', '1', '-W', '1', ip], capture_output=True, text=True, timeout=0.1)

            if result.returncode == 0:
                number_valid += 1
                if webhook in ['y']:

                    embed_content = {
                    'title': f'Ip Valid !',
                    'description': f"**Ip:**\n```{ip}```",
                    'color': 00000,
                    'footer': {
                    "text": "Novex",
                    "icon_url": "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAQxklEQVR4AQCBAH7/AOAtswDgLbMA4C2zAOAtswDgLbMA4C2zAOAtswDgLbMA4CyzAOAsswDhLLMA4SyzAOEsswThLLMQ4SyzH+EsszHhK7NE4iuzWOIrs2viK7N64iuzhOIqs4fjKrOD4yqzduMqs2LjKrNH4yqzKOMpswjkKbMA5CmzAOQpswDkKbMAAIEAfv8A4C2zAOAtswDgLbMA4C2zAOAtswDgLbMA4C2zAOAtswDgLLMA4CyzAOEsswDhLLMC4SyzC+EssxbhLLMl4SyzN+Ers0riK7Ne4iuzceIrs4DiK7OK4iuzjeMqs4jjKrN84yqzZ+Mqs03jKrMu4ymzDuMpswDkKbMA5CmzAOQpswAAgQB+/wDgLbMA4C2zAOAtswDgLbMA4C2zAOAtswDgLbMA4C2zAOAtswDgLLMD4CyzCOEssw7hLLMX4SyzI+EsszLhLLND4SyzV+Ers2riK7N94iuzjOIrs5XiK7OY4iqzlOMqs4fjKrNy4yqzWOMqsznjKrMZ4ymzAOMpswDkKbMA5CmzAACBAH7/AOAtswDgLbMA4C2zAOAtswDgLbMA4C2zBOAtswjgLbMM4C2zEOAtsxTgLLMY4CyzH+EssyjhLLM04SyzQ+Ess1ThLLNn4Suze+Irs43iK7Ob4iuzpeIrs6jiKrOj4yqzluMqs4HjKrNm4yqzR+MqsyfjKrMJ4ymzAOMpswDjKbMAAIEAfv8A4C2zAuAtswTgLbMH4C2zDOAtsxDgLbMV4C2zGuAtsx7gLbMi4C2zJ+AtsyzgLLMz4CyzPOEss0jhLLNW4SyzaOEss3rhLLOO4Suzn+Irs67iK7O34iuzueIrs7TiKrOn4yqzkuMqs3fjKrNY4yqzOOMqsxnjKrMA4yqzAOMqswAAgQB+/wDgLbMS4C2zFOAtsxfgLbMc4C2zIuAtsyfgLbMs4C2zMeAtszbgLbM74C2zQOAts0fgLbNR4CyzXOEss2vhLLN84SyzjuEss6HhLLOy4SuzwOIrs8niK7PL4iuzxeIrs7jiKrOj4yqziOMqs2njKrNJ4yqzKuMqsxDjKrMA4yqzAACBAH7/AOAtsyDgLbMi4C2zJuAtsyvgLbMx4C2zOOAtsz7gLbND4C2zSOAts07gLbNU4C2zW+Ats2TgLbNw4Cyzf+Ess4/hLLOh4Syzs+Ess8ThLLPR4Suz2uIrs9viK7PV4iuzx+Irs7LiKrOX4yqzeOMqs1jjKrM54yqzH+Mqsw3jKrMDAIEAfv8A3y6zK98usy7fLrMy3y6zON8tsz7fLbNF3y2zTN8ts1PgLbNZ4C2zXuAts2XgLbNs4C2zduAts4HgLbOP4C2zoOEss7HhLLPD4Syz0+Ess+DhLLPn4Suz6OIrs+LiK7PU4iuzvuIrs6PiK7OE4iqzY+Mqs0XjKrMr4yqzGOMqsw4AgQB+/wDfLrMz3y6zNd8uszrfLrNA3y6zSN8us0/fLrNX3y6zXt8us2XfLbNr3y2zcuAts3rgLbOD4C2zj+Ats5zgLbOs4C2zveAss87hLLPd4Syz6eEss/DhLLPx4Suz6uIrs9viK7PG4iuzquIrs4viK7Nr4iuzTOIqszPiKrMg4iqzFgCBAH7/AN8uszbfLrM53y6zPt8us0XfLrNN3y6zVt8us17fLrNm3y6zbd8us3TfLrN73y6zg98ts4zgLbOY4C2zpeAts7TgLbPE4C2z1OAts+PhLLPu4Syz9eEss/XhLLPt4Syz3uErs8jiK7Ot4iuzjeIrs23iK7NP4iuzNeIrsyPiK7MZAIEAfv8A3y6zNt8uszjfLrM+3y6zRd8us07fLrNX3y6zYd8us2nfLrNx3y6zed8us4DfLrOI3y6zkd8us5zfLbOp3y2zt+Ats8fgLbPW4C2z5OAts+7gLLP04Syz8+Ess+vhLLPc4SyzxuEss6rhK7OL4iuza+Irs03iK7Mz4iuzIeIrsxcAgQB+/wDeL7My3i+zNd4vszveL7ND3i+zTN4vs1beL7Ng3i6zad4us3LeLrN63y6zgd8us4nfLrOS3y6znd8us6nfLrO23y6zxd8ts9TgLbPg4C2z6uAts+/gLbPu4Cyz5eEss9bhLLO/4SyzpOEss4XhLLNl4SyzR+Ersy3hK7Mb4SuzEQCBAH7/AN4vsyveL7Mv3i+zNd4vsz3eL7NI3i+zUt4vs13eL7Nn3i+zcN4vs3jeL7OA3i+ziN4us5DfLrOa3y6zpt8us7LfLrPA3y6zzt8us9rfLbPi4C2z5uAts+XgLbPc4C2zzOAss7bhLLOa4Syze+Ess1vhLLM+4SyzJOEssxLhLLMJAIEAfv8A3i+zJN4vsyjeL7Mu3i+zN94vs0LeL7NN3i+zWd4vs2PeL7Ns3i+zdd4vs33eL7OE3i+zjd4vs5beL7Og3i6zrN8us7nfLrPG3y6z0d8us9nfLrPc3y2z2uAts9HgLbPB4C2zquAts4/gLbNw4CyzUeAsszPhLLMa4SyzCOEsswAAgQB+/wDdMLMd3TCzId0wsyjdMLMx3TCzPN0ws0jdMLNU3TCzX90ws2ndL7Nx3S+zed4vs4HeL7OI3i+zkd4vs5veL7Om3i+zsd4vs73eLrPH3y6zzt8us9HfLrPO3y6zxd8ts7XgLbOe4C2zg+Ats2XgLbNG4C2zKeAtsxDgLbMA4C2zAACBAH7/AN0wsxjdMLMb3TCzI90wsy3dMLM43TCzRd0ws1HdMLNc3TCzZt0ws2/dMLN23TCzfd0ws4TdMLOM3S+zld4vs5/eL7Oq3i+ztd4vs77eL7PE3i6zxt8us8PfLrO63y6zqd8us5PfLrN43y2zW+AtszzgLbMf4C2zB+AtswDgLbMAAIEAfv8A3DCzFNwwsxjcMLMg3DCzKtwwszbcMLND3DCzT9wws1vdMLNl3TCzbd0ws3XdMLN73TCzgt0ws4ndMLOR3TCzmt0ws6TdL7Ot3i+ztt4vs7veL7O93i+zud4vs7DeLrOg3y6zit8us3DfLrNS3y6zNN8usxjfLrMA3y6zAN8uswAAgQB+/wDcMbMT3DGzF9wxsx/cMbMp3DGzNtwxs0PcMbNQ3DGzW9wxs2XcMbNu3DGzddwxs3vcMLOB3DCzh90ws47dMLOW3TCzn90ws6jdMLOv3TCztN4vs7beL7Oy3i+zqN4vs5jeL7OD3i+zad4us0zfLrMv3y6zFN8uswDfLrMA3y6zAACBAH7/ANwxsxTcMbMY3DGzINwxsyvcMbM33DGzRdwxs1LcMbNe3DGzaNwxs3DcMbN33DGzfNwxs4HcMbOH3DGzjdwxs5TcMLOc3TCzo90ws6rdMLOv3TCzsN0ws6zdL7Oj3i+zk94vs37eL7Nl3i+zSd4vsyzeL7MS3i+zAN4vswDeL7MAAIEAfv8A2zKzFtsysxrbMrMi2zKzLdsyszrbMrNI2zKzVdsys2HbMrNr2zKzc9sys3nbMbN+2zGzgtwxs4fcMbOM3DGzktwxs5ncMbOg3DGzp9wws6vdMLOr3TCzqN0ws57dMLOQ3TCze90vs2PeL7NI3i+zLN4vsxLeL7MA3i+zAN4vswAAgQB+/wDbMrMY2zKzHdsysyXbMrMw2zKzPdsys0vbMrNY2zKzZNsys27bMrN22zKze9sys4DbMrOD2zKzh9sys4vbMbOR3DGzl9wxs53cMbOj3DGzp9wxs6jcMbOk3DCzm90ws43dMLN53TCzYt0ws0fdMLMs3TCzE90wswDdL7MA3S+zAACBAH7/ANozsxraM7Mf2jOzJ9ozszLaM7NA2jOzTdozs1vaM7Nm2jKzcNoys3faMrN92zKzgNsys4PbMrOG2zKzitsys4/bMrOU2zKzmtsxs5/cMbOj3DGzo9wxs6DcMbOY3DGzitwxs3fcMLNh3TCzR90wsy3dMLMV3TCzAN0wswDdMLMAAIEAfv8A2jOzG9ozsx/aM7Mn2jOzM9ozs0DaM7NO2jOzW9ozs2faM7Nw2jOzd9ozs3zaM7N/2jOzgtozs4TaMrOH2zKzi9sys4/bMrOV2zKzmtsys53bMrOe2zGzm9wxs5PcMbOG3DGzddwxs1/cMbNG3DGzLdwxsxbcMLMC3DCzANwwswAAgQB+/wDZM7MZ2TOzHdkzsyXaM7Mx2jOzPtozs0zaM7NZ2jOzZdozs27aM7N12jOzedozs3zaM7N92jOzf9ozs4HaM7OE2jOzidoys43bMrOS2zKzltsys5fbMrOU2zKzjdsys4HbMbNw3DGzW9wxs0TcMbMs3DGzFdwxswLcMbMA3DGzAACBAH7/ANk0sxTZNLMY2TSzINk0syzZNLM52TSzR9k0s1TZNLNg2TSzadk0s2/ZNLNz2TOzddkzs3baM7N32jOzedozs3vaM7N/2jOzhNozs4naM7OM2jKzjdsys4vbMrOF2zKzedsys2nbMrNW2zKzP9sxsyjcMbMS3DGzANwxswDcMbMAAIEAfv8A2TSzDNk0sxDZNLMZ2TSzJNk0szLZNLNA2TSzTdk0s1jZNLNh2TSzZ9k0s2rZNLNs2TSzbNk0s23ZNLNu2TOzcNozs3TaM7N42jOzfdozs4DaM7OC2jOzgNoys3rbMrNw2zKzYdsys07bMrM52zKzItsysw3bMrMA2zKzANsyswAAgQB+/wDZNLMC2TSzBtk0sw/ZNLMb2TSzKNk0szbZNLND2TSzTtk0s1bZNLNc2TSzX9k0s2DZNLNg2TSzYdk0s2HZNLNj2TSzZtkzs2vaM7Nv2jOzc9ozs3XaM7N02jOzbtozs2XaMrNX2zKzRdsyszDbMrMb2zKzBtsyswDbMrMA2zKzAACBAH7/ANg1swDYNbMA2DWzBNg1sw/YNbMd2DWzK9g1szfYNLNC2DSzS9g0s1DYNLNT2TSzVNk0s1TZNLNT2TSzVNk0s1XZNLNY2TSzXNk0s2HZM7Nl2jOzZ9ozs2baM7Ni2jOzWdozs0vaM7M62jKzJ9sysxLbMrMA2zKzANsyswDbMrMAAIEAfv8A2DWzANg1swDYNbMA2DWzBNg1sxLYNbMf2DWzLNg1szfYNbM/2DWzRNg1s0fYNbNI2DSzR9g0s0fZNLNH2TSzSNk0s0vZNLNP2TSzVNk0s1jZM7Na2jOzWtozs1baM7NN2jOzQdozszDaM7Md2jOzCdoyswDaMrMA2jKzANsyswAAgQB+/wDYNbMA2DWzANg1swDYNbMA2DWzCNg1sxXYNbMi2DWzLdg1szXYNbM62DWzPdg1sz3YNbM82DWzO9g0szvZNLM92TSzP9k0s0PZNLNI2TSzTNk0s0/ZNLNP2TOzS9ozs0PaM7M32jOzJ9ozsxXaM7MB2jOzANozswDaM7MA2jKzAACBAH7/ANg1swDYNbMA2DWzANg1swDYNbMA2DWzDtg1sxvYNbMl2DWzLdg1szLYNbM12DWzNdg1szTYNbMz2DWzM9g0szTZNLM32TSzO9k0s0DZNLNE2TSzR9k0s0fZM7ND2jOzPNozszDaM7Mg2jOzDtozswDaM7MA2jOzANozswDaM7MAAYEAfv8A2DWzANg1swDYNbMA2DWzANg1swDYNbMK2DWzF9g1syHYNbMp2DWzLtg1szHYNbMx2DWzMNg1sy/YNbMv2DSzMNg0szLZNLM22TSzO9k0s0DZNLNC2TSzQ9k0sz/ZM7M42jOzLNozsx3aM7ML2jOzANozswDaM7MA2jOzANozswCQp13X5BBfOwAAAABJRU5ErkJggg==",
                    }
                    }
                    send_webhook(embed_content)
                    print(f"{TYPE} Logs: {COLORAMA_RED}{number_invalid} invalid - {number_valid} valid{COLORAMA_GREEN} Status:  {COLORAMA_GREEN}Valid{COLORAMA_GREEN}  Ip: {COLORAMA_WHITE}{ip}{COLORAMA_GREEN}")
                else:
                    print(f"{TYPE} Logs: {COLORAMA_RED}{number_invalid} invalid - {number_valid} valid{COLORAMA_GREEN} Status:  {COLORAMA_GREEN}Valid{COLORAMA_GREEN}  Ip: {COLORAMA_WHITE}{ip}{COLORAMA_GREEN}")
                
            else:
                number_invalid += 1
                print(f"{TYPE} Logs: {COLORAMA_WHITE}{number_invalid} invalid - {number_valid} valid{COLORAMA_RED} Status: {COLORAMA_WHITE}Invalid{COLORAMA_RED} Ip: {COLORAMA_WHITE}{ip}{COLORAMA_RED}")
        except:
            number_invalid += 1
            print(f" Logs: {COLORAMA_WHITE}{number_invalid} invalid - {number_valid} valid{COLORAMA_RED} Status: {COLORAMA_WHITE}Invalid{COLORAMA_RED} Ip: {COLORAMA_WHITE}{ip}{COLORAMA_RED}")
        os.system(f"Title Ip Generator - Invalid: {number_invalid} - Valid: {number_valid}")

    def request():
        threads = []
        try:
            for _ in range(int(threads_number)):
                t = threading.Thread(target=ip_check)
                t.start()
                threads.append(t)
        except:
            print(f"{TYPE} ERROR")

        for thread in threads:
            thread.join()

    while True:
        request()
except Exception as e:
    (e)