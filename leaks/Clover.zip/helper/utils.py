# ------ Ethereum Multi Tool -----
import os
import ab5 
from                    ab5                    import vgratient
from                    colorama               import Fore, Style
from                    concurrent.futures     import ThreadPoolExecutor, as_completed
from                    dataclasses            import dataclass
from                    datetime               import datetime
from                    itertools              import cycle
from                    pystyle                import *
from                    time                   import sleep
import requests

import time
import                  subprocess
import                  socket
import random
import phonenumbers
from phonenumbers import geocoder, carrier, timezone





# ------ colors ------
COLOR_L1 = "\x1b[38;5;120m"
COLOR_L = "\x1b[38;5;118m"
COLOR_BANNER = "\x1b[38;5;135m"
COLOR_P1 = "\033[38;5;218m"
COLOR_P2 = "\033[38;5;213m"
COLOR_BLUE = "\033[94m"
COLOR_RESET = "\033[0m"
COLOR_PINK = "\033[38;5;176m"
COLOR_MAGENTA = "\033[38;5;97m"
COLOR_WHITE = "\u001b[37m"
COLOR_TOKEN = "\x1b[38;5;117m"

COLORAMA_RED = Fore.RED
COLORAMA_BLUE = Fore.BLUE
COLORAMA_CYAN = Fore.CYAN
COLORAMA_YELLOW = Fore.YELLOW
COLORAMA_LIGHTCYAN = Fore.LIGHTMAGENTA_EX + Fore.LIGHTCYAN_EX
COLORAMA_MAGENTA = Fore.MAGENTA
COLORAMA_ORANGE = Fore.RED + Fore.YELLOW
COLORAMA_GREEN = Fore.GREEN
COLORAMA_WHITE = Fore.WHITE
COLORAMA_GRAY = Fore.LIGHTBLACK_EX
COLORAMA_PINK = Fore.LIGHTGREEN_EX + Fore.LIGHTMAGENTA_EX
COLORAMA_RESET = Fore.RESET
COLORAMA_LIGHTMAGENTA = Fore.LIGHTMAGENTA_EX

s = Fore.LIGHTBLACK_EX
lr = Fore.LIGHTRED_EX
lg = '\x1b[38;5;10m'
ly = '\x1b[38;5;220m'
lb = Fore.LIGHTBLUE_EX

INPUT = f"                                        {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}]{COLORAMA_GRAY} | {COLOR_L}[{COLOR_L1}INPUT{COLOR_L}] {COLORAMA_WHITE}>"
TYPE = f"                                        {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}]{COLORAMA_GRAY} | {COLOR_L}[{COLOR_L1}INFO{COLOR_L}] {COLORAMA_WHITE}>"
ERRORM = f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}ERROR{COLOR_L}] {COLORAMA_GRAY}> {COLORAMA_RED}"


    

def clear(): #------------# Clear Terminal
    os.system("cls")

def clearprint(): #-------# Clear + Print
    clear()
    print(MainBanner)

def stresser2():
 stresser222 = f"""
              _____ __    _____ _____ _____ _____ 
             |     |  |  |     |  |  |   __| __  |
             |   --|  |__|  |  |  |  |   __|    -|
             |_____|_____|_____|\___/|_____|__|__| 
        
                type `methods` to list methods
                           
                               """
 print(f"{Center.XCenter(vgratient(stresser222, [3, 252, 40], [255, 255, 255]))}{COLOR_RESET}") 

def MainBanner():
 mainbanner = f"""
                                _____ __    _____ _____ _____ _____ 
                               |     |  |  |     |  |  |   __| __  |
                               |   --|  |__|  |  |  |  |   __|    -|
                               |_____|_____|_____|\___/|_____|__|__|                                   
                           """
 print(f"{Center.XCenter(vgratient(mainbanner, [3, 252, 40], [255, 255, 255]))}{COLOR_RESET}") 

# Directories and files to check
REQUIRED_PATHS = [
    "stats/input/sounds",
    "stats/input/tokens.txt",
    "stats/input/token-editor/pfp",
    "stats/output/grabber",
    "stats/output/passchanger/tokens.txt",
    "stats/output/token-data",
    "stats/output/token-data/formatted_tokens.txt",
    "stats/output/token-data/valid-tokens.txt"
]

def clear_screen():
    """Clears the terminal screen."""
    os.system('cls' if os.name == 'nt' else 'clear')

def display_ascii_banner():
    ascii_art = f"""
              _____ __    _____ _____ _____ _____ 
             |     |  |  |     |  |  |   __| __  |
             |   --|  |__|  |  |  |  |   __|    -|
             |_____|_____|_____|\___/|_____|__|__| 
                                  """
    welcome_message = f"                                  {COLOR_L}[{COLOR_WHITE}Bone Apple Tea!{COLOR_L}]{COLOR_RESET}"
    input_prompt = f"                                  {COLOR_L}[ETHERIUM] | [INPUT] {COLORAMA_GRAY} > {COLOR_WHITE}Press ENTER to continue. {COLOR_RESET}"

    print(f"{Center.XCenter(vgratient(ascii_art, [3, 252, 40], [255, 255, 255]))}{COLOR_RESET}") 
    print(welcome_message)
    print(input_prompt)
    input()  # Wait for user to press enter
    clear_screen()  # Clear the screen after pressing enter

def check_directories():
    """Check if all required directories and files exist."""
    missing_paths = []
    for path in REQUIRED_PATHS:
        if not os.path.exists(path):
            missing_paths.append(path)
    
    if missing_paths:
        # If there are missing directories or files, alert the user
        MainBanner()
        alert_message = f"                          {COLOR_L}[ETHERIUM] | {COLORAMA_GRAY}Looks like some files are missing. Press ENTER to restore them.{COLOR_RESET}"
        print(alert_message)
        input()  # Wait for user input to proceed with restoring
        create_directories(missing_paths)
    else:
        MainBanner()

        print(f"                                      {COLOR_L}[ETHERIUM] | {COLORAMA_GRAY}All directories and files are intact.{COLOR_RESET}")
        time.sleep(1)

def create_directories(missing_paths):
    os.system("cls")
    MainBanner()
    info_message = f"                         {COLOR_L}[ETHERIUM] | [INFO] {COLORAMA_GRAY}> Restoring missing directories...{COLOR_RESET}"
    print(info_message)

    for path in missing_paths:
        time.sleep(0.5)  
        if '.' in path.split('/')[-1]: 
            dir_path = os.path.dirname(path)
            os.makedirs(dir_path, exist_ok=True)
            with open(path, 'w') as f:  
                pass
        else:
            os.makedirs(path, exist_ok=True)  
            os.system("cls")
            MainBanner()
        done_message = f"                        {COLOR_L}[ETHERIUM] | [DONE] {COLORAMA_GRAY}> {COLOR_WHITE}{path}{COLOR_RESET}"
        print(done_message)

    final_message = f"                        {COLOR_L}[ETHERIUM] | [INFO] {COLORAMA_GRAY}> All missing directories restored successfully!{COLOR_RESET}"
    print(final_message)



def set_console_size(width_px=957, height_px=340):
    char_width = width_px // 7
    char_height = height_px // 16
    os.system(f"mode con: cols={char_width} lines={char_height}")