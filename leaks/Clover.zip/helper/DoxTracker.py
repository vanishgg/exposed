

from utils import *
try:
    import webbrowser
except Exception as e:
   (e)
   

try:
    (f"""
 {TYPE}00 Back
 {TYPE}01{COLORAMA_WHITE} Username
 {TYPE}02{COLORAMA_WHITE} LastName, FirstName
 {TYPE}03{COLORAMA_WHITE} Other
    """)

    search_type = input(f"{INPUT} Search Type -> {COLORAMA_RESET}")

    if search_type in ['00', '0']:
         

     if search_type in ['01', '1']:
        search = input(f"{INPUT} Username -> {COLORAMA_RESET}")
        (search)
            
    elif search_type in ['02', '2']:
        name = input(f"{INPUT} LastName -> {COLORAMA_RESET}")
        first_name = input(f"{INPUT} FirstName -> {COLORAMA_RESET}")
        (name)
        (first_name)
        
    elif search_type in ['03', '3']:
        search = input(f"{INPUT} Search -> {COLORAMA_RESET}")
        (search)
    else:
        

     if search_type in ['1', '01','2','02','3','03']:
        print(f"""
{COLORAMA_WHITE}[{COLORAMA_RED}00{COLORAMA_WHITE}] {COLORAMA_RED}-> Back
{COLORAMA_WHITE}[{COLORAMA_RED}01{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Facebook.com
{COLORAMA_WHITE}[{COLORAMA_RED}02{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Youtube.com
{COLORAMA_WHITE}[{COLORAMA_RED}03{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Twitter.com
{COLORAMA_WHITE}[{COLORAMA_RED}04{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Tiktok.com
{COLORAMA_WHITE}[{COLORAMA_RED}05{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Peekyou.com
{COLORAMA_WHITE}[{COLORAMA_RED}06{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} Tumblr.com
{COLORAMA_WHITE}[{COLORAMA_RED}07{COLORAMA_WHITE}] {COLORAMA_RED}->{COLORAMA_WHITE} PagesJaunes.fr
    """)
    while True:
        
        if search_type in ['1', '01','2','02','3','03']:
            choice = input(f"{INPUT} Site >  ")

            if choice in ['0', '00']:
                break

            elif choice in ['01', '1']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.facebook.com/search/top/?init=quick&q={search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.facebook.com/search/top/?init=quick&q={name}%20{first_name}")

            elif choice in ['02', '2']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.youtube.com/results?search_query={search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.youtube.com/results?search_query={name}+{first_name}")
        
            elif choice in ['03', '3']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://twitter.com/search?f=users&vertical=default&q={search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://twitter.com/search?f=users&vertical=default&q={name}%20{first_name}")
        
            elif choice in ['04', '4']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.tiktok.com/search?q={search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.tiktok.com/search?q={name}%20{first_name}")

            elif choice in ['05', '5']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.peekyou.com/{search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.peekyou.com/{name}_{first_name}")

            elif choice in ['06', '6']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.tumblr.com/search/{search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.tumblr.com/search/{name}%20{first_name}")

            elif choice in ['07', '7']:
                if search_type in ['01', '1', '3', '03']:
                    webbrowser.open(f"https://www.pagesjaunes.fr/pagesblanches/recherche?quoiqui={search}")
                elif search_type in ['02', '2']:
                    webbrowser.open(f"https://www.pagesjaunes.fr/pagesblanches/recherche?quoiqui={name}%20{first_name}")

except Exception as e:
    (e)